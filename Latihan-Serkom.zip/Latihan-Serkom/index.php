<?php
$conn=mysqli_connect("localhost","root","","test_laundry") or die("DB Error");

// SAVE
if(isset($_POST['save'])){
  $idp=$_POST['id_pelanggan']??null;
  $idl=$_POST['id_laundry']??null;
  $j=$_POST['jumlah']??null;
  if($idp && $idl && $j){
    $t1=date("Y-m-d");$t2=date("Y-m-d",strtotime("+3 days"));
    mysqli_query($conn,"INSERT INTO transaksi(id_pelanggan,tanggal_terima,tanggal_selesai) VALUES('$idp','$t1','$t2')");
    $id=mysqli_insert_id($conn);
    $h=mysqli_fetch_assoc(mysqli_query($conn,"SELECT harga_per_pcs FROM jenis_laundry WHERE id_laundry='$idl'"))['harga_per_pcs'];
    mysqli_query($conn,"INSERT INTO detail_transaksi(id_transaksi,id_laundry,jumlah,harga) VALUES('$id','$idl','$j','$h')");
  }
}

// UPDATE
if(isset($_POST['update']) && isset($_GET['edit'])){
  $id=$_GET['edit'];
  $idp=$_POST['id_pelanggan']??null;
  $idl=$_POST['id_laundry']??null;
  $j=$_POST['jumlah']??null;
  if($idp && $idl && $j){
    $h=mysqli_fetch_assoc(mysqli_query($conn,"SELECT harga_per_pcs FROM jenis_laundry WHERE id_laundry='$idl'"))['harga_per_pcs'];
    mysqli_query($conn,"UPDATE transaksi SET id_pelanggan='$idp' WHERE id_transaksi='$id'");
    mysqli_query($conn,"UPDATE detail_transaksi SET id_laundry='$idl',jumlah='$j',harga='$h' WHERE id_transaksi='$id'");
  }
}

// DELETE
if(isset($_POST['delete']) && isset($_GET['edit'])){
  $id=$_GET['edit'];
  mysqli_query($conn,"DELETE FROM detail_transaksi WHERE id_transaksi='$id'");
  mysqli_query($conn,"DELETE FROM transaksi WHERE id_transaksi='$id'");
}

// DATA
$trans=mysqli_query($conn,"SELECT t.id_transaksi,p.nama_pelanggan,t.tanggal_terima,t.tanggal_selesai,
 j.nama_barang,j.satuan,d.jumlah,d.harga,(d.jumlah*d.harga) total
 FROM transaksi t JOIN pelanggan p ON t.id_pelanggan=p.id_pelanggan
 JOIN detail_transaksi d ON t.id_transaksi=d.id_transaksi
 JOIN jenis_laundry j ON d.id_laundry=j.id_laundry");

$edit=null;
if(isset($_GET['edit'])){
  $id=$_GET['edit'];
  $edit=mysqli_fetch_assoc(mysqli_query($conn,"SELECT t.id_pelanggan,d.id_laundry,d.jumlah 
  FROM transaksi t JOIN detail_transaksi d ON t.id_transaksi=d.id_transaksi WHERE t.id_transaksi='$id'"));
}
?>
<!DOCTYPE html><html><head><title>Laundry</title>
<style>
body{font-family:Arial}.container{display:flex;gap:20px}
table{border-collapse:collapse;width:650px}td,th{border:1px solid #000;padding:5px;text-align:center;cursor:pointer}
tr.sel{background:#ffe08a}form{display:flex;flex-direction:column;gap:6px}
button{padding:5px 15px;margin:2px}
</style></head><body>
<div class="container">

<!-- TABEL -->
<div>
<h3>Data Transaksi</h3>
<table>
<tr><th>No</th><th>Pelanggan</th><th>Terima</th><th>Selesai</th><th>Jenis</th><th>Harga</th><th>Jumlah</th><th>Total</th></tr>
<?php $n=1;while($r=mysqli_fetch_assoc($trans)){?>
<tr onclick="location='?edit=<?=$r['id_transaksi']?>'" class="<?=isset($_GET['edit'])&&$_GET['edit']==$r['id_transaksi']?'sel':''?>">
<td><?=$n++?></td><td><?=$r['nama_pelanggan']?></td><td><?=$r['tanggal_terima']?></td><td><?=$r['tanggal_selesai']?></td>
<td><?=$r['nama_barang']?></td><td><?=$r['harga']?></td><td><?=$r['jumlah']?></td><td><?=$r['total']?></td></tr><?php }?></table><br>
</div>

<!-- FORM -->
<div>
<h3>Form Input</h3>
<form method="post">
<select name="id_pelanggan">
  <option>-- Pilih Pelanggan --</option>
  <?php $q=mysqli_query($conn,"SELECT * FROM pelanggan");while($p=mysqli_fetch_assoc($q)){?>
  <option value="<?=$p['id_pelanggan']?>" <?= $edit&&$edit['id_pelanggan']==$p['id_pelanggan']?'selected':''?>><?=$p['nama_pelanggan']?></option>
  <?php }?></select>

<select name="id_laundry" id="barang" onchange="upd()">
  <option>-- Pilih Jenis --</option>
  <?php $q=mysqli_query($conn,"SELECT * FROM jenis_laundry");while($j=mysqli_fetch_assoc($q)){?>
  <option value="<?=$j['id_laundry']?>" data-harga="<?=$j['harga_per_pcs']?>" <?= $edit&&$edit['id_laundry']==$j['id_laundry']?'selected':''?>><?=$j['nama_barang']?></option>
  <?php }?></select>

<input type="text" id="harga" placeholder="Harga" readonly>
<input type="number" name="jumlah" id="jumlah" value="<?=@$edit['jumlah']?>" placeholder="Jumlah" oninput="upd()">
<input type="text" id="total" placeholder="Total" readonly>

<button name="save">SAVE</button>
<?php if($edit){ ?>
<button name="update">UPDATE</button>
<button name="delete" onclick="return confirm('Hapus?')">DELETE</button>
<?php } ?>
</form>
</div>
</div>
<script>
function upd(){let b=document.getElementById("barang"),h=b.options[b.selectedIndex].dataset.harga||0;
let j=document.getElementById("jumlah").value||0;document.getElementById("harga").value=h;document.getElementById("total").value=h*j;}
</script>
</body></html>