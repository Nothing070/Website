<?php
session_start();

echo "<h3>Debug Session</h3>";
echo "<!-- Debug: Session ID = " . session_id() . " -->";
echo "<!-- Debug: Session Save Path = " . session_save_path() . " -->";
echo "<!-- Debug: Session Writable = " . (is_writable(session_save_path()) ? 'Yes' : 'No') . " -->";

echo "<pre>";
print_r($_SESSION);
echo "</pre>";

if (isset($_SESSION['user_id'])) {
    echo "<p>User ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Username: " . $_SESSION['username'] . "</p>";
    echo "<p>Role: " . $_SESSION['role'] . "</p>";
} else {
    echo "<p>Not logged in</p>";
}
?>