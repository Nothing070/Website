<?php
require_once '../../includes/auth.php';

// Check if user is admin
if ($_SESSION['role'] != 'admin') {
    header('Location: ../dashboard.php');
    exit();
}

require_once '../../config/database.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Prevent deleting self
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: index.php?success=deleted');
    } else {
        header('Location: index.php?error=self');
    }
    exit();
}

// Handle edit status
if (isset($_GET['toggle_status'])) {
    $id = $_GET['toggle_status'];
    $stmt = $pdo->prepare("UPDATE users SET status = NOT status WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: index.php?success=status_updated');
    exit();
}

// Get all users
$stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll();
?>

<?php include '../../includes/header.php'; ?>

<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2><i class="fas fa-users-cog"></i> Kelola User</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/pages/dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Kelola User</li>
                    </ol>
                </nav>
            </div>
            <a href="tambah.php" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Tambah User
            </a>
        </div>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle"></i> 
        <?php 
        if ($_GET['success'] == 'deleted') echo 'User berhasil dihapus!';
        elseif ($_GET['success'] == 'status_updated') echo 'Status user berhasil diperbarui!';
        else echo 'Data berhasil disimpan!';
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (isset($_GET['error']) && $_GET['error'] == 'self'): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <i class="fas fa-exclamation-circle"></i> Anda tidak dapat menghapus akun sendiri!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Nama Lengkap</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Dibuat Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['username']; ?></td>
                        <td><?php echo $user['nama_lengkap']; ?></td>
                        <td>
                            <span class="badge bg-<?php 
                                echo $user['role'] == 'admin' ? 'danger' : 
                                     ($user['role'] == 'bendahara' ? 'warning' : 'info'); 
                            ?>">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?php echo $user['status'] ? 'success' : 'secondary'; ?>">
                                <?php echo $user['status'] ? 'Aktif' : 'Nonaktif'; ?>
                            </span>
                        </td>
                        <td><?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="index.php?toggle_status=<?php echo $user['id']; ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Toggle Status">
                                <i class="fas fa-toggle-<?php echo $user['status'] ? 'on' : 'off'; ?>"></i>
                            </a>
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <a href="index.php?delete=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger confirm-delete" data-bs-toggle="tooltip" title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>