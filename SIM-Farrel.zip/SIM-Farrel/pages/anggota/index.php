<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM anggota WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: index.php?success=deleted');
    exit();
}

// Get all anggota
$stmt = $pdo->query("SELECT * FROM anggota ORDER BY created_at DESC");
$anggota = $stmt->fetchAll();
?>

<?php include '../../includes/header.php'; ?>

<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2><i class="fas fa-user-friends"></i> Data Anggota</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/pages/dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Data Anggota</li>
                    </ol>
                </nav>
            </div>
            <a href="tambah.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Anggota
            </a>
        </div>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle"></i> Data berhasil <?php echo $_GET['success'] == 'deleted' ? 'dihapus' : 'disimpan'; ?>!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>NIA</th>
                        <th>Nama Lengkap</th>
                        <th>Jenis Kelamin</th>
                        <th>No HP</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($anggota as $a): ?>
                    <tr>
                        <td>
                            <?php if ($a['foto']): ?>
                                <img src="../../assets/images/<?php echo $a['foto']; ?>" class="rounded-circle" width="40" height="40">
                            <?php else: ?>
                                <i class="fas fa-user-circle fa-2x text-muted"></i>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $a['nia']; ?></td>
                        <td><?php echo $a['nama_lengkap']; ?></td>
                        <td><?php echo $a['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                        <td><?php echo $a['no_hp']; ?></td>
                        <td><?php echo $a['jabatan']; ?></td>
                        <td>
                            <span class="badge bg-<?php echo $a['status'] == 'aktif' ? 'success' : 'secondary'; ?>">
                                <?php echo ucfirst($a['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="detail.php?id=<?php echo $a['id']; ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="edit.php?id=<?php echo $a['id']; ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="index.php?delete=<?php echo $a['id']; ?>" class="btn btn-sm btn-danger confirm-delete" data-bs-toggle="tooltip" title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>