<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

// Get filter parameters
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Get financial data
$queryMasuk = "SELECT DATE_FORMAT(tanggal, '%Y-%m') as periode, SUM(jumlah) as total 
               FROM kas_masuk 
               WHERE YEAR(tanggal) = :tahun 
               GROUP BY DATE_FORMAT(tanggal, '%Y-%m')
               ORDER BY periode";

$queryKeluar = "SELECT DATE_FORMAT(tanggal, '%Y-%m') as periode, SUM(jumlah) as total 
                FROM kas_keluar 
                WHERE YEAR(tanggal) = :tahun 
                GROUP BY DATE_FORMAT(tanggal, '%Y-%m')
                ORDER BY periode";

$stmtMasuk = $pdo->prepare($queryMasuk);
$stmtMasuk->bindParam(':tahun', $tahun);
$stmtMasuk->execute();
$dataMasuk = $stmtMasuk->fetchAll(PDO::FETCH_KEY_PAIR);

$stmtKeluar = $pdo->prepare($queryKeluar);
$stmtKeluar->bindParam(':tahun', $tahun);
$stmtKeluar->execute();
$dataKeluar = $stmtKeluar->fetchAll(PDO::FETCH_KEY_PAIR);

// Get totals
$totalMasuk = array_sum($dataMasuk);
$totalKeluar = array_sum($dataKeluar);
$saldo = $totalMasuk - $totalKeluar;

// Get monthly data
$months = [];
for ($i = 1; $i <= 12; $i++) {
    $monthKey = sprintf('%04d-%02d', $tahun, $i);
    $months[] = [
        'periode' => $monthKey,
        'masuk' => $dataMasuk[$monthKey] ?? 0,
        'keluar' => $dataKeluar[$monthKey] ?? 0,
        'saldo' => ($dataMasuk[$monthKey] ?? 0) - ($dataKeluar[$monthKey] ?? 0)
    ];
}
?>

<?php include '../includes/header.php'; ?>

<div class="row">
    <div class="col-md-12">
        <h2><i class="fas fa-chart-line"></i> Laporan Keuangan</h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/pages/dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item active">Laporan Keuangan</li>
            </ol>
        </nav>
    </div>
</div>

<!-- Filter Form -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Tahun</label>
                <select class="form-select" name="tahun">
                    <?php for ($y = 2020; $y <= date('Y') + 1; $y++): ?>
                    <option value="<?php echo $y; ?>" <?php echo $y == $tahun ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Bulan</label>
                <select class="form-select" name="bulan">
                    <option value="">Semua Bulan</option>
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                    <option value="<?php echo str_pad($m, 2, '0', STR_PAD_LEFT); ?>" <?php echo $m == $bulan ? 'selected' : ''; ?>>
                        <?php echo date('F', mktime(0, 0, 0, $m, 1)); ?>
                    </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary me-2">
                    <i class="fas fa-filter"></i> Filter
                </button>
                <button type="button" class="btn btn-success" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Summary Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h6 class="card-title">Total Kas Masuk</h6>
                <h3 class="mb-0">Rp <?php echo number_format($totalMasuk, 0, ',', '.'); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <h6 class="card-title">Total Kas Keluar</h6>
                <h3 class="mb-0">Rp <?php echo number_format($totalKeluar, 0, ',', '.'); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h6 class="card-title">Saldo Akhir</h6>
                <h3 class="mb-0">Rp <?php echo number_format($saldo, 0, ',', '.'); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h6 class="card-title">Tahun Laporan</h6>
                <h3 class="mb-0"><?php echo $tahun; ?></h3>
            </div>
        </div>
    </div>
</div>

<!-- Monthly Report Table -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0">Laporan Bulanan Tahun <?php echo $tahun; ?></h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Bulan</th>
                        <th>Kas Masuk</th>
                        <th>Kas Keluar</th>
                        <th>Saldo Bulanan</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($months as $month): ?>
                    <tr>
                        <td><?php echo date('F', mktime(0, 0, 0, substr($month['periode'], 5, 2), 1)); ?></td>
                        <td class="text-success">Rp <?php echo number_format($month['masuk'], 0, ',', '.'); ?></td>
                        <td class="text-danger">Rp <?php echo number_format($month['keluar'], 0, ',', '.'); ?></td>
                        <td class="<?php echo $month['saldo'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                            Rp <?php echo number_format($month['saldo'], 0, ',', '.'); ?>
                        </td>
                        <td>
                            <?php if ($month['saldo'] > 0): ?>
                                <span class="badge bg-success">Surplus</span>
                            <?php elseif ($month['saldo'] < 0): ?>
                                <span class="badge bg-danger">Defisit</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Balance</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot class="table-dark">
                    <tr>
                        <th>TOTAL</th>
                        <th>Rp <?php echo number_format($totalMasuk, 0, ',', '.'); ?></th>
                        <th>Rp <?php echo number_format($totalKeluar, 0, ',', '.'); ?></th>
                        <th>Rp <?php echo number_format($saldo, 0, ',', '.'); ?></th>
                        <th>
                            <?php if ($saldo > 0): ?>
                                <span class="badge bg-success">Surplus</span>
                            <?php elseif ($saldo < 0): ?>
                                <span class="badge bg-danger">Defisit</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Balance</span>
                            <?php endif; ?>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- Chart -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Grafik Perbandingan Kas Masuk dan Keluar</h5>
    </div>
    <div class="card-body">
        <canvas id="financeChart" height="100"></canvas>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('financeChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [
                <?php foreach ($months as $month): ?>
                '<?php echo date('M', mktime(0, 0, 0, substr($month['periode'], 5, 2), 1)); ?>',
                <?php endforeach; ?>
            ],
            datasets: [{
                label: 'Kas Masuk',
                data: [
                    <?php foreach ($months as $month): ?>
                    <?php echo $month['masuk']; ?>,
                    <?php endforeach; ?>
                ],
                backgroundColor: 'rgba(25, 135, 84, 0.8)',
                borderColor: 'rgba(25, 135, 84, 1)',
                borderWidth: 1
            }, {
                label: 'Kas Keluar',
                data: [
                    <?php foreach ($months as $month): ?>
                    <?php echo $month['keluar']; ?>,
                    <?php endforeach; ?>
                ],
                backgroundColor: 'rgba(220, 53, 69, 0.8)',
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': Rp ' + context.parsed.y.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>