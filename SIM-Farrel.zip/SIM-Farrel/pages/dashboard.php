<?php
require_once '../includes/auth.php';
require_once '../config/database.php';

// Get statistics
$totalAnggota = $pdo->query("SELECT COUNT(*) FROM anggota")->fetchColumn();
$anggotaAktif = $pdo->query("SELECT COUNT(*) FROM anggota WHERE status = 'aktif'")->fetchColumn();
$totalKegiatan = $pdo->query("SELECT COUNT(*) FROM kegiatan")->fetchColumn();
$kegiatanBerjalan = $pdo->query("SELECT COUNT(*) FROM kegiatan WHERE status = 'berjalan'")->fetchColumn();

// Get financial statistics
$totalKasMasuk = $pdo->query("SELECT COALESCE(SUM(jumlah), 0) FROM kas_masuk")->fetchColumn();
$totalKasKeluar = $pdo->query("SELECT COALESCE(SUM(jumlah), 0) FROM kas_keluar")->fetchColumn();
$saldoKas = $totalKasMasuk - $totalKasKeluar;

// Get recent activities
$recentKegiatan = $pdo->query("SELECT * FROM kegiatan ORDER BY created_at DESC LIMIT 5")->fetchAll();
$recentAnggota = $pdo->query("SELECT * FROM anggota ORDER BY created_at DESC LIMIT 5")->fetchAll();
$recentKasMasuk = $pdo->query("SELECT km.*, u.nama_lengkap as created_by_name, a.nama_lengkap as anggota_name 
                                FROM kas_masuk km 
                                LEFT JOIN users u ON km.created_by = u.id 
                                LEFT JOIN anggota a ON km.id_anggota = a.id 
                                ORDER BY km.created_at DESC LIMIT 5")->fetchAll();
$recentKasKeluar = $pdo->query("SELECT kk.*, u.nama_lengkap as created_by_name, k.nama_kegiatan 
                                FROM kas_keluar kk 
                                LEFT JOIN users u ON kk.created_by = u.id 
                                LEFT JOIN kegiatan k ON kk.id_kegiatan = k.id 
                                ORDER BY kk.created_at DESC LIMIT 5")->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<!-- Main Content -->
<div class="container-fluid px-4">
    <!-- Page Heading -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4">
        <div class="mb-3 mb-md-0">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <p class="text-gray-600 mb-0">Selamat datang kembali, <span class="fw-bold"><?php echo $_SESSION['nama_lengkap']; ?></span>!</p>
        </div>
        <div class="d-flex align-items-center">
            <div class="text-end me-3">
                <div class="text-sm text-gray-500">Terakhir login</div>
                <div class="text-sm font-weight-bold"><?php echo date('d F Y, H:i'); ?></div>
            </div>
            <div class="dropdown">
                <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#"><i class="fas fa-download me-2"></i>Export Data</a></li>
                    <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i>Pengaturan</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
        <!-- Total Anggota Card -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stats-card border-0 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="stats-icon bg-primary bg-opacity-10 text-primary">
                            <i class="fas fa-users fa-lg"></i>
                        </div>
                        <div class="badge bg-primary bg-opacity-10 text-primary">
                            <i class="fas fa-arrow-up"></i> 12%
                        </div>
                    </div>
                    <h2 class="stats-number mb-1"><?php echo $totalAnggota; ?></h2>
                    <p class="stats-label text-muted mb-0">Total Anggota</p>
                    <div class="progress mt-3" style="height: 4px;">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 75%"></div>
                    </div>
                    <small class="text-muted"><?php echo $anggotaAktif; ?> aktif</small>
                </div>
            </div>
        </div>

        <!-- Total Kegiatan Card -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stats-card border-0 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="stats-icon bg-success bg-opacity-10 text-success">
                            <i class="fas fa-calendar-check fa-lg"></i>
                        </div>
                        <div class="badge bg-success bg-opacity-10 text-success">
                            <i class="fas fa-arrow-up"></i> 8%
                        </div>
                    </div>
                    <h2 class="stats-number mb-1"><?php echo $totalKegiatan; ?></h2>
                    <p class="stats-label text-muted mb-0">Total Kegiatan</p>
                    <div class="progress mt-3" style="height: 4px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 60%"></div>
                    </div>
                    <small class="text-muted"><?php echo $kegiatanBerjalan; ?> berjalan</small>
                </div>
            </div>
        </div>

        <!-- Total Kas Masuk Card -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stats-card border-0 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="stats-icon bg-info bg-opacity-10 text-info">
                            <i class="fas fa-arrow-down fa-lg"></i>
                        </div>
                        <div class="badge bg-info bg-opacity-10 text-info">
                            <i class="fas fa-arrow-up"></i> 15%
                        </div>
                    </div>
                    <h2 class="stats-number mb-1">Rp<?php echo number_format($totalKasMasuk, 0, ',', '.'); ?></h2>
                    <p class="stats-label text-muted mb-0">Total Kas Masuk</p>
                    <div class="progress mt-3" style="height: 4px;">
                        <div class="progress-bar bg-info" role="progressbar" style="width: 85%"></div>
                    </div>
                    <small class="text-muted">+12% dari bulan lalu</small>
                </div>
            </div>
        </div>

        <!-- Saldo Kas Card -->
        <div class="col-12 col-sm-6 col-xl-3">
            <div class="card stats-card border-0 shadow-sm h-100">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div class="stats-icon bg-warning bg-opacity-10 text-warning">
                            <i class="fas fa-wallet fa-lg"></i>
                        </div>
                        <div class="badge <?php echo $saldoKas >= 0 ? 'bg-success' : 'bg-danger'; ?> bg-opacity-10 <?php echo $saldoKas >= 0 ? 'text-success' : 'text-danger'; ?>">
                            <i class="fas fa-arrow-<?php echo $saldoKas >= 0 ? 'up' : 'down'; ?>"></i>
                        </div>
                    </div>
                    <h2 class="stats-number mb-1">Rp<?php echo number_format($saldoKas, 0, ',', '.'); ?></h2>
                    <p class="stats-label text-muted mb-0">Saldo Kas</p>
                    <div class="progress mt-3" style="height: 4px;">
                        <div class="progress-bar <?php echo $saldoKas >= 0 ? 'bg-success' : 'bg-danger'; ?>" role="progressbar" style="width: <?php echo min(100, max(0, ($saldoKas / $totalKasMasuk) * 100)); ?>%"></div>
                    </div>
                    <small class="text-muted"><?php echo $saldoKas >= 0 ? 'Cukup' : 'Kurang'; ?></small>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="row g-4 mb-4">
        <!-- Finance Chart -->
        <div class="col-12 col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 pt-4 px-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title mb-0">Ringkasan Keuangan</h5>
                            <p class="text-muted text-sm mb-0">6 bulan terakhir</p>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">6 Bulan</a></li>
                                <li><a class="dropdown-item" href="#">1 Tahun</a></li>
                                <li><a class="dropdown-item" href="#">Semua</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="#">Export</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="chart-container" style="height: 300px;">
                        <canvas id="financeChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pie Chart -->
        <div class="col-12 col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 pt-4 px-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title mb-0">Perbandingan Kas</h5>
                            <p class="text-muted text-sm mb-0">Overview</p>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Detail</a></li>
                                <li><a class="dropdown-item" href="#">Laporan</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="#">Export</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="chart-container" style="height: 250px;">
                        <canvas id="kasChart"></canvas>
                    </div>
                    <div class="mt-4">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="w-8 h-8 rounded-full bg-success bg-opacity-10 d-flex align-items-center justify-content-center me-2">
                                        <i class="fas fa-arrow-down text-success"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm text-muted">Masuk</div>
                                        <div class="fw-bold">Rp<?php echo number_format($totalKasMasuk, 0, ',', '.'); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="d-flex align-items-center">
                                    <div class="w-8 h-8 rounded-full bg-danger bg-opacity-10 d-flex align-items-center justify-content-center me-2">
                                        <i class="fas fa-arrow-up text-danger"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm text-muted">Keluar</div>
                                        <div class="fw-bold">Rp<?php echo number_format($totalKasKeluar, 0, ',', '.'); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="row g-4 mb-4">
        <!-- Kas Masuk Terbaru -->
        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 pt-4 px-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title mb-0">Kas Masuk Terbaru</h5>
                            <p class="text-muted text-sm mb-0">5 transaksi terakhir</p>
                        </div>
                        <a href="kas/masuk.php" class="btn btn-sm btn-primary">
                            Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Sumber</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentKasMasuk as $kas): ?>
                                <tr>
                                    <td>
                                        <div class="text-sm"><?php echo date('d/m/Y', strtotime($kas['tanggal'])); ?></div>
                                    <div class="text-xs text-muted"><?php echo date('H:i', strtotime($kas['tanggal'])); ?></div>
                                    </td>
                                    <td><?php echo $kas['sumber']; ?></td>
                                    <td>
                                        <div class="fw-bold text-success">Rp<?php echo number_format($kas['jumlah'], 0, ',', '.'); ?></div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kas Keluar Terbaru -->
        <div class="col-12 col-lg-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 pt-4 px-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="card-title mb-0">Kas Keluar Terbaru</h5>
                            <p class="text-muted text-sm mb-0">5 transaksi terakhir</p>
                        </div>
                        <a href="kas/keluar.php" class="btn btn-sm btn-danger">
                            Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>
                <div class="card-body px-4 pb-4">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Keperluan</th>
                                    <th>Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentKasKeluar as $kas): ?>
                                <tr>
                                    <td>
                                        <div class="text-sm"><?php echo date('d/m/Y', strtotime($kas['tanggal'])); ?></div>
                                        <div class="text-xs text-muted"><?php echo date('H:i', strtotime($kas['tanggal'])); ?></div>
                                    </td>
                                    <td><?php echo $kas['keperluan']; ?></td>
                                    <td>
                                        <div class="fw-bold text-danger">Rp<?php echo number_format($kas['jumlah'], 0, ',', '.'); ?></div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="row g-4 mb-4">
        <!-- Today's Activities -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 text-center">
                    <div class="stats-icon-lg mx-auto mb-3 bg-primary bg-opacity-10 text-primary">
                        <i class="fas fa-calendar-day fa-2x"></i>
                    </div>
                    <h3 class="stats-number-lg mb-1"><?php 
                        $today = date('Y-m-d');
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM kegiatan WHERE tanggal = ?");
                        $stmt->execute([$today]);
                        echo $stmt->fetchColumn();
                    ?></h3>
                    <p class="stats-label text-muted mb-0">Kegiatan Hari Ini</p>
                </div>
            </div>
        </div>

        <!-- New Members -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 text-center">
                    <div class="stats-icon-lg mx-auto mb-3 bg-success bg-opacity-10 text-success">
                        <i class="fas fa-user-plus fa-2x"></i>
                    </div>
                    <h3 class="stats-number-lg mb-1"><?php 
                        $week_ago = date('Y-m-d', strtotime('-7 days'));
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM anggota WHERE tanggal_bergabung >= ?");
                        $stmt->execute([$week_ago]);
                        echo $stmt->fetchColumn();
                    ?></h3>
                    <p class="stats-label text-muted mb-0">Anggota Baru</p>
                </div>
            </div>
        </div>

        <!-- Growth Rate -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 text-center">
                    <div class="stats-icon-lg mx-auto mb-3 bg-info bg-opacity-10 text-info">
                        <i class="fas fa-chart-line fa-2x"></i>
                    </div>
                    <h3 class="stats-number-lg mb-1">+<?php 
                        $last_month = date('Y-m', strtotime('-1 month'));
                        $stmt = $pdo->prepare("SELECT COALESCE(SUM(jumlah), 0) FROM kas_masuk WHERE DATE_FORMAT(tanggal, '%Y-%m') = ?");
                        $stmt->execute([$last_month]);
                        $last_month_total = $stmt->fetchColumn();
                        
                        $this_month = date('Y-m');
                        $stmt = $pdo->prepare("SELECT COALESCE(SUM(jumlah), 0) FROM kas_masuk WHERE DATE_FORMAT(tanggal, '%Y-%m') = ?");
                        $stmt->execute([$this_month]);
                        $this_month_total = $stmt->fetchColumn();
                        
                        if ($last_month_total > 0) {
                            $growth = (($this_month_total - $last_month_total) / $last_month_total) * 100;
                            echo number_format($growth, 1);
                        } else {
                            echo '100';
                        }
                    ?>%</h3>
                    <p class="stats-label text-muted mb-0">Pertumbuhan Kas</p>
                </div>
            </div>
        </div>

        <!-- Active Users -->
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body p-4 text-center">
                    <div class="stats-icon-lg mx-auto mb-3 bg-warning bg-opacity-10 text-warning">
                        <i class="fas fa-users-cog fa-2x"></i>
                    </div>
                    <h3 class="stats-number-lg mb-1"><?php 
                        $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 1");
                        echo $stmt->fetchColumn();
                    ?></h3>
                    <p class="stats-label text-muted mb-0">User Aktif</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Stats Cards */
.stats-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.stats-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.1) !important;
}

.stats-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stats-icon-lg {
    width: 64px;
    height: 64px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stats-number {
    font-size: 1.75rem;
    font-weight: 700;
    line-height: 1;
}

.stats-number-lg {
    font-size: 2rem;
    font-weight: 700;
    line-height: 1;
}

.stats-label {
    font-size: 0.875rem;
    font-weight: 500;
}

/* Chart Containers */
.chart-container {
    position: relative;
}

/* Progress Bars */
.progress {
    background-color: #e9ecef;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .stats-number {
        font-size: 1.5rem;
    }
    
    .stats-number-lg {
        font-size: 1.75rem;
    }
    
    .stats-icon {
        width: 40px;
        height: 40px;
    }
    
    .stats-icon-lg {
        width: 56px;
        height: 56px;
    }
    
    .card-body {
        padding: 1rem !important;
    }
}

@media (max-width: 576px) {
    .stats-number {
        font-size: 1.25rem;
    }
    
    .stats-number-lg {
        font-size: 1.5rem;
    }
    
    .d-flex.flex-column .text-end {
        text-align: left !important;
        margin-top: 0.5rem;
    }
}

/* Utility Classes */
.w-8 {
    width: 2rem !important;
}

.h-8 {
    height: 2rem !important;
}

/* Card Hover Effects */
.card {
    transition: all 0.3s ease;
}

.card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.1) !important;
}

/* Table Styling */
.table th {
    border-top: none;
    font-weight: 600;
    color: #6b7280;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.table td {
    vertical-align: middle;
    padding: 0.75rem 0.5rem;
}

/* Badge Styling */
.badge {
    font-size: 0.75rem;
    padding: 0.35em 0.65em;
    font-weight: 500;
}
</style>

<script>
// Initialize Charts
document.addEventListener('DOMContentLoaded', function() {
    // Finance Chart
    const financeCtx = document.getElementById('financeChart').getContext('2d');
    new Chart(financeCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Kas Masuk',
                data: [5000000, 7500000, 6000000, 8500000, 7000000, 9000000, 8000000, 9500000, 8500000, 9000000, 9500000, 10000000],
                backgroundColor: 'rgba(25, 135, 84, 0.1)',
                borderColor: 'rgba(25, 135, 84, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(25, 135, 84, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.4,
                fill: true
            }, {
                label: 'Kas Keluar',
                data: [3000000, 4500000, 4000000, 5500000, 5000000, 6000000, 5500000, 6500000, 6000000, 7000000, 7500000, 8000000],
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(220, 53, 69, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                    align: 'end',
                    labels: {
                        usePointStyle: true,
                        padding: 15,
                        boxWidth: 8
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: '#ddd',
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': Rp ' + context.parsed.y.toLocaleString('id-ID');
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + (value / 1000000).toFixed(0) + 'M';
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
    
    // Kas Chart
    const kasCtx = document.getElementById('kasChart').getContext('2d');
    new Chart(kasCtx, {
        type: 'doughnut',
        data: {
            labels: ['Kas Masuk', 'Kas Keluar'],
            datasets: [{
                data: [<?php echo $totalKasMasuk; ?>, <?php echo $totalKasKeluar; ?>],
                backgroundColor: [
                    'rgba(25, 135, 84, 0.8)',
                    'rgba(220, 53, 69, 0.8)'
                ],
                borderColor: [
                    'rgba(25, 135, 84, 1)',
                    'rgba(220, 53, 69, 1)'
                ],
                borderWidth: 2,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    borderColor: '#ddd',
                    borderWidth: 1,
                    cornerRadius: 8,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += 'Rp ' + context.parsed.toLocaleString('id-ID');
                            return label;
                        }
                    }
                }
            },
            cutout: '70%',
            animation: {
                animateRotate: true,
                animateScale: true
            }
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>