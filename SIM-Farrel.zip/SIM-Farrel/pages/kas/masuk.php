<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM kas_masuk WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: masuk.php?success=deleted');
    exit();
}

// Get all kas masuk
$stmt = $pdo->query("SELECT km.*, u.nama_lengkap as created_by_name, a.nama_lengkap as anggota_name 
                      FROM kas_masuk km 
                      LEFT JOIN users u ON km.created_by = u.id 
                      LEFT JOIN anggota a ON km.id_anggota = a.id 
                      ORDER BY km.tanggal DESC");
$kasMasuk = $stmt->fetchAll();

// Get total kas masuk
$totalKasMasuk = $pdo->query("SELECT COALESCE(SUM(jumlah), 0) FROM kas_masuk")->fetchColumn();
?>

<?php include '../../includes/header.php'; ?>

<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2><i class="fas fa-arrow-down"></i> Kas Masuk</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/pages/dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Kas Masuk</li>
                    </ol>
                </nav>
            </div>
            <a href="tambah_masuk.php" class="btn btn-success">
                <i class="fas fa-plus"></i> Tambah Kas Masuk
            </a>
        </div>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle"></i> Data berhasil <?php echo $_GET['success'] == 'deleted' ? 'dihapus' : 'disimpan'; ?>!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Summary Card -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Total Kas Masuk</h6>
                        <h3 class="mb-0">Rp <?php echo number_format($totalKasMasuk, 0, ',', '.'); ?></h3>
                    </div>
                    <div class="fs-1">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Jumlah Transaksi</h6>
                        <h3 class="mb-0"><?php echo count($kasMasuk); ?></h3>
                    </div>
                    <div class="fs-1">
                        <i class="fas fa-receipt"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Rata-rata</h6>
                        <h3 class="mb-0">Rp <?php echo count($kasMasuk) > 0 ? number_format($totalKasMasuk / count($kasMasuk), 0, ',', '.') : '0'; ?></h3>
                    </div>
                    <div class="fs-1">
                        <i class="fas fa-calculator"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th>Kode Transaksi</th>
                        <th>Tanggal</th>
                        <th>Sumber</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Dibuat Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kasMasuk as $kas): ?>
                    <tr>
                        <td><span class="badge bg-success"><?php echo $kas['kode_transaksi']; ?></span></td>
                        <td><?php echo date('d/m/Y', strtotime($kas['tanggal'])); ?></td>
                        <td><?php echo $kas['sumber']; ?></td>
                        <td><strong>Rp <?php echo number_format($kas['jumlah'], 0, ',', '.'); ?></strong></td>
                        <td><?php echo $kas['keterangan'] ?: '-'; ?></td>
                        <td><?php echo $kas['created_by_name']; ?></td>
                        <td>
                            <a href="detail_masuk.php?id=<?php echo $kas['id']; ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="edit_masuk.php?id=<?php echo $kas['id']; ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="masuk.php?delete=<?php echo $kas['id']; ?>" class="btn btn-sm btn-danger confirm-delete" data-bs-toggle="tooltip" title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>