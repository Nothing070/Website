<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM kas_keluar WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: keluar.php?success=deleted');
    exit();
}

// Get all kas keluar
$stmt = $pdo->query("SELECT kk.*, u.nama_lengkap as created_by_name, k.nama_kegiatan 
                      FROM kas_keluar kk 
                      LEFT JOIN users u ON kk.created_by = u.id 
                      LEFT JOIN kegiatan k ON kk.id_kegiatan = k.id 
                      ORDER BY kk.tanggal DESC");
$kasKeluar = $stmt->fetchAll();

// Get total kas keluar
$totalKasKeluar = $pdo->query("SELECT COALESCE(SUM(jumlah), 0) FROM kas_keluar")->fetchColumn();
?>

<?php include '../../includes/header.php'; ?>

<div class="row">
    <div class="col-md-12">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2><i class="fas fa-arrow-up"></i> Kas Keluar</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo $base_url; ?>/pages/dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Kas Keluar</li>
                    </ol>
                </nav>
            </div>
            <a href="tambah_keluar.php" class="btn btn-danger">
                <i class="fas fa-plus"></i> Tambah Kas Keluar
            </a>
        </div>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="fas fa-check-circle"></i> Data berhasil <?php echo $_GET['success'] == 'deleted' ? 'dihapus' : 'disimpan'; ?>!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Summary Card -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Total Kas Keluar</h6>
                        <h3 class="mb-0">Rp <?php echo number_format($totalKasKeluar, 0, ',', '.'); ?></h3>
                    </div>
                    <div class="fs-1">
                        <i class="fas fa-arrow-up"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Jumlah Transaksi</h6>
                        <h3 class="mb-0"><?php echo count($kasKeluar); ?></h3>
                    </div>
                    <div class="fs-1">
                        <i class="fas fa-receipt"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Rata-rata</h6>
                        <h3 class="mb-0">Rp <?php echo count($kasKeluar) > 0 ? number_format($totalKasKeluar / count($kasKeluar), 0, ',', '.') : '0'; ?></h3>
                    </div>
                    <div class="fs-1">
                        <i class="fas fa-calculator"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th>Kode Transaksi</th>
                        <th>Tanggal</th>
                        <th>Keperluan</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Dibuat Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kasKeluar as $kas): ?>
                    <tr>
                        <td><span class="badge bg-danger"><?php echo $kas['kode_transaksi']; ?></span></td>
                        <td><?php echo date('d/m/Y', strtotime($kas['tanggal'])); ?></td>
                        <td><?php echo $kas['keperluan']; ?></td>
                        <td><strong>Rp <?php echo number_format($kas['jumlah'], 0, ',', '.'); ?></strong></td>
                        <td><?php echo $kas['keterangan'] ?: '-'; ?></td>
                        <td><?php echo $kas['created_by_name']; ?></td>
                        <td>
                            <a href="detail_keluar.php?id=<?php echo $kas['id']; ?>" class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="edit_keluar.php?id=<?php echo $kas['id']; ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="keluar.php?delete=<?php echo $kas['id']; ?>" class="btn btn-sm btn-danger confirm-delete" data-bs-toggle="tooltip" title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>