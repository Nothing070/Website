<?php
// Cek apakah session sudah aktif sebelum memulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: /SIM-Farrel/login.php');
    exit();
}

// Base URL untuk path yang konsisten
$base_url = '/SIM-Farrel';
?>