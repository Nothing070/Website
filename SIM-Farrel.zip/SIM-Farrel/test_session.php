<?php
session_start();

echo "<h3>Session Test</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

if (isset($_SESSION['user_id'])) {
    echo "<p>User ID: " . $_SESSION['user_id'] . "</p>";
    echo "<p>Username: " . $_SESSION['username'] . "</p>";
    echo "<p>Role: " . $_SESSION['role'] . "</p>";
} else {
    echo "<p>Not logged in</p>";
}

echo "<p><a href='/SIM-Farrel/Pages/dashboard.php'>Go to Dashboard</a></p>";
?>