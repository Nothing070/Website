<?php
// Cek apakah session sudah aktif sebelum memulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Enable error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
require_once '../config/database.php';

// Cek apakah form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Ambil username dan password dari form
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Validasi input
    if(empty($username) || empty($password)) {
        header("location: /SIM-Farrel/login.php?error=empty");
        exit();
    }
    
    // Prepare SQL statement
    $sql = "SELECT id, username, password, nama_lengkap, role, status FROM users WHERE username = :username";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        
        // Cek apakah user ada
        if ($stmt->rowCount() == 1) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verifikasi password
            if (password_verify($password, $user['password'])) {
                // Cek status user
                if ($user['status'] == 1) {
                    // Regenerate session ID untuk security
                    session_regenerate_id();
                    
                    // Set session variables
                    $_SESSION["loggedin"] = true;
                    $_SESSION["user_id"] = $user["id"];
                    $_SESSION["username"] = $user["username"]; 
                    $_SESSION["nama_lengkap"] = $user["nama_lengkap"];
                    $_SESSION["role"] = $user["role"];
                    
                    // Redirect ke dashboard dengan path yang benar
                    header("location: /SIM-Farrel/Pages/dashboard.php");
                    exit();
                } else {
                    // User tidak aktif
                    header("location: /SIM-Farrel/login.php?error=inactive");
                    exit();
                }
            } else {
                // Password salah
                header("location: /SIM-Farrel/login.php?error=invalid");
                exit();
            }
        } else {
            // User tidak ditemukan
            header("location: /SIM-Farrel/login.php?error=notfound");
            exit();
        }
    } catch(PDOException $e) {
        // Database error
        die("Error: " . $e->getMessage());
    }
} else {
    // Bukan POST request
    header("location: /SIM-Farrel/login.php");
    exit();
}
?>