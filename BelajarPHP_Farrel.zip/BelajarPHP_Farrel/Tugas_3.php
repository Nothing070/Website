<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 3</title>
</head>
<body>
    <h2><b>Deret Fibonaci</b></h2>
    <br>
    <?php
    
    function fibonacci($a = 0, $b = 1) {
        if ($a <= 100) {
            echo $a . " ";
            fibonacci($b, $a + $b);
        }
    }

    echo "Deret Fibonacci hingga 100: <br><br>";
    fibonacci();
    ?>
</body>
</html>