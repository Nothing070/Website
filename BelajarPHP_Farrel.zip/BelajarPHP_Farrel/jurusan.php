<?php

$jurusan = $_POST['jurusan'];

if ($jurusan == "TKP"){
    echo "Jurusanmu adalah Teknik Konstruksi dan Properti";
} else if ($jurusan == "RPL"){
    echo "Jurusanmu adalah Rekayasa Perangkat Lunak";
} else if ($jurusan == "TKR"){
    echo "Jurusanmu adalah Teknik Kendaraan Ringan";
} else if ($jurusan == "TSM"){
    echo "Jurusanmu adalah Teknik Sepeda Motor";
} else if ($jurusan == "TM"){
    echo "Jurusanmu adalah Teknik Mesin";
} else if ($jurusan == "TEI"){
    echo "Jurusanmu adalah Teknik Elektronika Industri";
} else if ($jurusan == "TOI"){
    echo "Jurusanmu adalah Teknik Otomasi Industri";
} else if ($jurusan == "DPIB"){
    echo "Jurusanmu adalah Desain Permodelan dan Informasi Bangunan";
} else {
    echo "Kamu bukan siswa SMKN 5 Surakarta";
}
?>