<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 2</title>
    <style>
        table {
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: center;
            border: 5px solid red;
        }
        th, td {
            border: 1px solid red;
            padding: 8px;
        }
        th {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center; color: red;">Table Menggunakan Perulangan</h2>
    <table style="margin: auto;">
        <?php
        for ($i = 1; $i <= 10; $i++) {
            echo "<tr>";
            for ($j = 1; $j <= 10; $j++) {
                $result = $i * $j;
                echo "<td>$result</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>