<?php
function indonesia(){
    echo "Selamat datang di webku <br>";
}
function inggris(){
    echo "Welcome to my web <br>";
}
function jerman(){
    echo "Willkommen auf meiner web <br>";
}
function italia(){
    echo "Benvenuti nel mio web <br>";
}
$bahasa="jerman";
$bahasa();
$bahasa="indonesia";
$bahasa();
?>