<?php
$nama = "Farrel Adyatma Putra";
$nisn = "23358";
$ttl = "20/01/2008";
$umur = "17";
$asal = "SMKN 5 Surakarta";
$hobi = "Bermain bola";
$skor1 = 87.90 ;
$skor2 = 79.43 ;
$lolos = false ;

print '<h1><span style="color: red;">Test</span></h1><br>';
print '<h2><span style="color: green;">Test</span></h2><br>';
print '<h3><span style="color: blue;">Test</span></h3><br>';
print '<h4><span style="color: yellow;">Test</span></h4><br>';
print '<h5><span style="color: purple;">Test</span></h5><br>';
print '<h6><span style="color: orange;">Test</span></h6><br>';

echo "Nama = " .$nama. "<br>";
echo "Nisn = " .$nisn. "<br>";
echo "Tangal Lahir = " .$ttl. "<br>";
echo "Umur = " .$umur. "<br>";
echo "Asal Sekolah = " .$asal. "<br>";
echo "Hobi = " .$hobi. "<br>";
echo "Total = " .$skor1 + $skor2. "<br>";

if($lolos == true)
    echo "<h3> Peserta lolos ke babak selanjutnya</h3>";
else
    echo "Peserta harus berhenti disini";
?>