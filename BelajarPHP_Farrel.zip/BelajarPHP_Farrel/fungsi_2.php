<?php
function hitumur($thn_lhr, $thn_now){
    $umur = $thn_now - $thn_lhr;
    return $umur;
}

$umursaya = hitumur(2000, 2020);
echo "umur saya adalah " .$umursaya." tahun";
?>