<?php
echo "perulangan dengan while <br>";
$i = 1;
while ($i <= 10){
    echo $i;
    $i++;
}
echo "<br>";

echo "perulangan dengan do while <br>";
$i=1;
do{
    echo $i;
    $i++;
}
while($i<=10);
echo "<br>";

echo "perulangan dengan for <br>";
for( $i =1; $i<=10; $i++){
    echo $i;
}
?>