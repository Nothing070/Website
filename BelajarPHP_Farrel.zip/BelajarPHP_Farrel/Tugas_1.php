<?php

$nama = $_POST['nama'];

echo "Nama: " .htmlspecialchars($nama). "<br>"; 

$kelas = $_POST['kelas'];

echo "Kelas: " .htmlspecialchars($kelas). "<br>"; 

$nilai = $_POST['nilai'];

echo "Nilai: " .htmlspecialchars($nilai). "<br>";

$nilai = $_POST['nilai'];

if ($nilai >= 86 && $nilai <= 100){
    echo "Grade nilai siswa : A";
} else if ($nilai >= 73 && $nilai < 85 ){
    echo "Grade nilai siswa : B";
} else if ($nilai >= 61 && $nilai < 72){
    echo "Grade nilai siswa : C";
} else if ($nilai >= 51 && $nilai < 60){
    echo "Grade nilai siswa : D";
} else if ($nilai < 50){
    echo "Grade nilai siswa : E";
} else {
    echo "Anda belum memasukkan nilai";
}
?>