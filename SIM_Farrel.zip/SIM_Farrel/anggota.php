<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();
cek_role(['admin', 'ketua', 'sekretaris']);

$page_title = 'Data Anggota';

// Proses tambah anggota
if (isset($_POST['tambah_anggota'])) {
    // Data User
    $username = esc($_POST['username']);
    $password = md5($_POST['password']);
    $nama_lengkap = esc($_POST['nama_lengkap']);
    $email = esc($_POST['email']);
    $role = esc($_POST['role']);
    
    // Data Anggota
    $nik = esc($_POST['nik']);
    $tempat_lahir = esc($_POST['tempat_lahir']);
    $tanggal_lahir = esc($_POST['tanggal_lahir']);
    $jenis_kelamin = esc($_POST['jenis_kelamin']);
    $alamat = esc($_POST['alamat']);
    $no_telp = esc($_POST['no_telp']);
    $pekerjaan = esc($_POST['pekerjaan']);
    $status_anggota = esc($_POST['status_anggota']);
    $tanggal_bergabung = esc($_POST['tanggal_bergabung']);
    
    // Cek username dan email
    $check = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' OR email = '$email'");
    if (mysqli_num_rows($check) > 0) {
        set_alert('danger', 'Username atau email sudah terdaftar!');
    } else {
        // Insert user
        $query_user = "INSERT INTO users (username, password, nama_lengkap, email, role) 
                       VALUES ('$username', '$password', '$nama_lengkap', '$email', '$role')";
        
        if (mysqli_query($conn, $query_user)) {
            $user_id = mysqli_insert_id($conn);
            
            // Insert anggota
            $query_anggota = "INSERT INTO anggota (user_id, nik, tempat_lahir, tanggal_lahir, jenis_kelamin, alamat, no_telp, pekerjaan, status_anggota, tanggal_bergabung) 
                              VALUES ('$user_id', '$nik', '$tempat_lahir', '$tanggal_lahir', '$jenis_kelamin', '$alamat', '$no_telp', '$pekerjaan', '$status_anggota', '$tanggal_bergabung')";
            
            if (mysqli_query($conn, $query_anggota)) {
                set_alert('success', 'Anggota berhasil ditambahkan!');
            }
        }
    }
    header('Location: anggota.php');
    exit();
}

// Proses update anggota
if (isset($_POST['update_anggota'])) {
    $id = esc($_POST['anggota_id']);
    $user_id = esc($_POST['user_id']);
    
    // Update user
    $nama_lengkap = esc($_POST['nama_lengkap']);
    $email = esc($_POST['email']);
    $role = esc($_POST['role']);
    
    $query_user = "UPDATE users SET nama_lengkap = '$nama_lengkap', email = '$email', role = '$role' 
                   WHERE id = '$user_id'";
    mysqli_query($conn, $query_user);
    
    // Update anggota
    $nik = esc($_POST['nik']);
    $tempat_lahir = esc($_POST['tempat_lahir']);
    $tanggal_lahir = esc($_POST['tanggal_lahir']);
    $jenis_kelamin = esc($_POST['jenis_kelamin']);
    $alamat = esc($_POST['alamat']);
    $no_telp = esc($_POST['no_telp']);
    $pekerjaan = esc($_POST['pekerjaan']);
    $status_anggota = esc($_POST['status_anggota']);
    
    $query_anggota = "UPDATE anggota SET 
                      nik = '$nik', 
                      tempat_lahir = '$tempat_lahir', 
                      tanggal_lahir = '$tanggal_lahir', 
                      jenis_kelamin = '$jenis_kelamin', 
                      alamat = '$alamat', 
                      no_telp = '$no_telp', 
                      pekerjaan = '$pekerjaan', 
                      status_anggota = '$status_anggota' 
                      WHERE id = '$id'";
    
    if (mysqli_query($conn, $query_anggota)) {
        set_alert('success', 'Data anggota berhasil diupdate!');
    }
    header('Location: anggota.php');
    exit();
}

// Proses hapus anggota
if (isset($_GET['hapus'])) {
    $user_id = esc($_GET['hapus']);
    $query = "DELETE FROM users WHERE id = '$user_id'";
    if (mysqli_query($conn, $query)) {
        set_alert('success', 'Anggota berhasil dihapus!');
    }
    header('Location: anggota.php');
    exit();
}

// Filter
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$filter_role = isset($_GET['role']) ? $_GET['role'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$where = "WHERE 1=1";
if ($filter_status) {
    $where .= " AND a.status_anggota = '$filter_status'";
}
if ($filter_role) {
    $where .= " AND u.role = '$filter_role'";
}
if ($search) {
    $where .= " AND (u.nama_lengkap LIKE '%$search%' OR a.nik LIKE '%$search%')";
}

// Pagination
$per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Hitung total data
$count_query = "SELECT COUNT(*) as total FROM anggota a 
                LEFT JOIN users u ON a.user_id = u.id $where";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];

// Ambil data anggota
$query = "SELECT a.*, u.username, u.nama_lengkap, u.email, u.role, u.foto_profil 
          FROM anggota a 
          LEFT JOIN users u ON a.user_id = u.id 
          $where
          ORDER BY u.nama_lengkap ASC 
          LIMIT $per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

include 'includes/header.php';
?>

<!-- Stats -->
<div class="stats-cards">
    <?php
    $stats_query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN a.status_anggota = 'aktif' THEN 1 ELSE 0 END) as aktif,
                    SUM(CASE WHEN a.status_anggota = 'non-aktif' THEN 1 ELSE 0 END) as non_aktif,
                    SUM(CASE WHEN a.jenis_kelamin = 'L' THEN 1 ELSE 0 END) as laki,
                    SUM(CASE WHEN a.jenis_kelamin = 'P' THEN 1 ELSE 0 END) as perempuan
                    FROM anggota a";
    $stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_query));
    ?>
    
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['total']; ?></h3>
            <p>Total Anggota</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-user-check"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['aktif']; ?></h3>
            <p>Anggota Aktif</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon orange">
            <i class="fas fa-male"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['laki']; ?></h3>
            <p>Laki-laki</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon red">
            <i class="fas fa-female"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['perempuan']; ?></h3>
            <p>Perempuan</p>
        </div>
    </div>
</div>

<!-- Data Anggota -->
<div class="card">
    <div class="card-header">
        <h4><i class="fas fa-users"></i> Data Anggota Karang Taruna</h4>
        <?php if ($_SESSION['role'] == 'admin'): ?>
        <button class="btn btn-primary btn-sm" onclick="openModal('modalTambah')">
            <i class="fas fa-user-plus"></i> Tambah Anggota
        </button>
        <?php endif; ?>
    </div>
    
    <!-- Filter -->
    <div style="padding: 20px; background: #f9fafb; border-radius: 10px; margin-bottom: 20px;">
        <form method="GET" action="" style="display: flex; gap: 15px; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 200px;">
                <input type="text" name="search" class="form-control" placeholder="Cari nama atau NIK..." 
                       value="<?php echo $search; ?>">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <select name="status" class="form-control">
                    <option value="">Semua Status</option>
                    <option value="aktif" <?php echo $filter_status == 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                    <option value="non-aktif" <?php echo $filter_status == 'non-aktif' ? 'selected' : ''; ?>>Non-Aktif</option>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <select name="role" class="form-control">
                    <option value="">Semua Role</option>
                    <option value="admin" <?php echo $filter_role == 'admin' ? 'selected' : ''; ?>>Admin</option>
                    <option value="ketua" <?php echo $filter_role == 'ketua' ? 'selected' : ''; ?>>Ketua</option>
                    <option value="sekretaris" <?php echo $filter_role == 'sekretaris' ? 'selected' : ''; ?>>Sekretaris</option>
                    <option value="bendahara" <?php echo $filter_role == 'bendahara' ? 'selected' : ''; ?>>Bendahara</option>
                    <option value="anggota" <?php echo $filter_role == 'anggota' ? 'selected' : ''; ?>>Anggota</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-filter"></i> Filter
            </button>
            
            <a href="anggota.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-redo"></i> Reset
            </a>
        </form>
    </div>
    
    <!-- Tabel -->
    <div class="table-responsive">
        <table id="tableAnggota">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Nama Lengkap</th>
                    <th>NIK</th>
                    <th>Jenis Kelamin</th>
                    <th>No. Telp</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = $offset + 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td>
                            <img src="<?php echo FOTO_PROFIL_DIR . $row['foto_profil']; ?>" 
                                 style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;" 
                                 alt="Foto" onerror="this.src='assets/img/default.jpg'">
                        </td>
                        <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                        <td><?php echo $row['nik'] ?? '-'; ?></td>
                        <td><?php echo $row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                        <td><?php echo $row['no_telp'] ?? '-'; ?></td>
                        <td><span class="badge badge-info"><?php echo ucfirst($row['role']); ?></span></td>
                        <td>
                            <?php if ($row['status_anggota'] == 'aktif'): ?>
                                <span class="badge badge-success">Aktif</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Non-Aktif</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button onclick="showDetail(<?php echo htmlspecialchars(json_encode($row)); ?>)" 
                                    class="btn btn-sm" style="background: var(--secondary); color: white;">
                                <i class="fas fa-eye"></i>
                            </button>
                            <?php if ($_SESSION['role'] == 'admin'): ?>
                            <button onclick="editAnggota(<?php echo htmlspecialchars(json_encode($row)); ?>)" 
                                    class="btn btn-sm" style="background: var(--warning); color: white;">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="?hapus=<?php echo $row['user_id']; ?>" 
                               onclick="return confirmDelete()" 
                               class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" style="text-align: center;">Tidak ada data anggota</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php echo pagination($total_data, $per_page, $page, 'anggota.php'); ?>
</div>

<!-- Modal Tambah Anggota -->
<div id="modalTambah" class="modal">
    <div class="modal-content" style="max-width: 800px; max-height: 90vh; overflow-y: auto;">
        <span class="close-modal" onclick="closeModal('modalTambah')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-user-plus"></i> Tambah Anggota Baru</h3>
        
        <form method="POST" action="">
            <h4 style="margin-bottom: 15px; color: var(--primary);">Data Akun</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>Username *</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Password *</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Role *</label>
                    <select name="role" class="form-control" required>
                        <option value="anggota">Anggota</option>
                        <option value="ketua">Ketua</option>
                        <option value="sekretaris">Sekretaris</option>
                        <option value="bendahara">Bendahara</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
            </div>
            
            <hr style="margin: 20px 0;">
            
            <h4 style="margin-bottom: 15px; color: var(--primary);">Data Pribadi</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>NIK *</label>
                    <input type="text" name="nik" class="form-control" required maxlength="16">
                </div>
                
                <div class="form-group">
                    <label>No. Telepon *</label>
                    <input type="text" name="no_telp" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tempat Lahir *</label>
                    <input type="text" name="tempat_lahir" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tanggal Lahir *</label>
                    <input type="date" name="tanggal_lahir" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Jenis Kelamin *</label>
                    <select name="jenis_kelamin" class="form-control" required>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Pekerjaan *</label>
                    <input type="text" name="pekerjaan" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Status Anggota *</label>
                    <select name="status_anggota" class="form-control" required>
                        <option value="aktif">Aktif</option>
                        <option value="non-aktif">Non-Aktif</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Tanggal Bergabung *</label>
                    <input type="date" name="tanggal_bergabung" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Alamat *</label>
                    <textarea name="alamat" class="form-control" rows="3" required></textarea>
                </div>
            </div>
            
            <button type="submit" name="tambah_anggota" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Data
            </button>
        </form>
    </div>
</div>

<!-- Modal Edit Anggota -->
<div id="modalEdit" class="modal">
    <div class="modal-content" style="max-width: 800px; max-height: 90vh; overflow-y: auto;">
        <span class="close-modal" onclick="closeModal('modalEdit')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-edit"></i> Edit Data Anggota</h3>
        
        <form method="POST" action="">
            <input type="hidden" name="anggota_id" id="edit_anggota_id">
            <input type="hidden" name="user_id" id="edit_user_id">
            
            <h4 style="margin-bottom: 15px; color: var(--primary);">Data Akun</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" id="edit_email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Role *</label>
                    <select name="role" id="edit_role" class="form-control" required>
                        <option value="anggota">Anggota</option>
                        <option value="ketua">Ketua</option>
                        <option value="sekretaris">Sekretaris</option>
                        <option value="bendahara">Bendahara</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
            </div>
            
            <hr style="margin: 20px 0;">
            
            <h4 style="margin-bottom: 15px; color: var(--primary);">Data Pribadi</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" id="edit_nama_lengkap" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>NIK *</label>
                    <input type="text" name="nik" id="edit_nik" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>No. Telepon *</label>
                    <input type="text" name="no_telp" id="edit_no_telp" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tempat Lahir *</label>
                    <input type="text" name="tempat_lahir" id="edit_tempat_lahir" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tanggal Lahir *</label>
                    <input type="date" name="tanggal_lahir" id="edit_tanggal_lahir" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Jenis Kelamin *</label>
                    <select name="jenis_kelamin" id="edit_jenis_kelamin" class="form-control" required>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Pekerjaan *</label>
                    <input type="text" name="pekerjaan" id="edit_pekerjaan" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Status Anggota *</label>
                    <select name="status_anggota" id="edit_status_anggota" class="form-control" required>
                        <option value="aktif">Aktif</option>
                        <option value="non-aktif">Non-Aktif</option>
                    </select>
                </div>
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Alamat *</label>
                    <textarea name="alamat" id="edit_alamat" class="form-control" rows="3" required></textarea>
                </div>
            </div>
            
            <button type="submit" name="update_anggota" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Data
            </button>
        </form>
    </div>
</div>

<!-- Modal Detail Anggota -->
<div id="modalDetail" class="modal">
    <div class="modal-content" style="max-width: 600px;">
        <span class="close-modal" onclick="closeModal('modalDetail')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-user"></i> Detail Anggota</h3>
        
        <div id="detailContent" style="line-height: 2;"></div>
    </div>
</div>

<script>
function editAnggota(data) {
    document.getElementById('edit_anggota_id').value = data.id;
    document.getElementById('edit_user_id').value = data.user_id;
    document.getElementById('edit_nama_lengkap').value = data.nama_lengkap;
    document.getElementById('edit_email').value = data.email;
    document.getElementById('edit_role').value = data.role;
    document.getElementById('edit_nik').value = data.nik || '';
    document.getElementById('edit_no_telp').value = data.no_telp || '';
    document.getElementById('edit_tempat_lahir').value = data.tempat_lahir || '';
    document.getElementById('edit_tanggal_lahir').value = data.tanggal_lahir || '';
    document.getElementById('edit_jenis_kelamin').value = data.jenis_kelamin || 'L';
    document.getElementById('edit_pekerjaan').value = data.pekerjaan || '';
    document.getElementById('edit_status_anggota').value = data.status_anggota || 'aktif';
    document.getElementById('edit_alamat').value = data.alamat || '';
    openModal('modalEdit');
}

function showDetail(data) {
    const content = `
        <table style="width: 100%;">
            <tr><td style="width: 40%;"><strong>Nama Lengkap</strong></td><td>: ${data.nama_lengkap}</td></tr>
            <tr><td><strong>NIK</strong></td><td>: ${data.nik || '-'}</td></tr>
            <tr><td><strong>Email</strong></td><td>: ${data.email}</td></tr>
            <tr><td><strong>Username</strong></td><td>: ${data.username}</td></tr>
            <tr><td><strong>Role</strong></td><td>: ${data.role.charAt(0).toUpperCase() + data.role.slice(1)}</td></tr>
            <tr><td><strong>Tempat, Tgl Lahir</strong></td><td>: ${data.tempat_lahir || '-'}, ${data.tanggal_lahir || '-'}</td></tr>
            <tr><td><strong>Jenis Kelamin</strong></td><td>: ${data.jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'}</td></tr>
            <tr><td><strong>No. Telepon</strong></td><td>: ${data.no_telp || '-'}</td></tr>
            <tr><td><strong>Pekerjaan</strong></td><td>: ${data.pekerjaan || '-'}</td></tr>
            <tr><td><strong>Alamat</strong></td><td>: ${data.alamat || '-'}</td></tr>
            <tr><td><strong>Status</strong></td><td>: ${data.status_anggota == 'aktif' ? '<span class="badge badge-success">Aktif</span>' : '<span class="badge badge-danger">Non-Aktif</span>'}</td></tr>
            <tr><td><strong>Tanggal Bergabung</strong></td><td>: ${data.tanggal_bergabung || '-'}</td></tr>
        </table>
    `;
    document.getElementById('detailContent').innerHTML = content;
    openModal('modalDetail');
}
</script>

<?php include 'includes/footer.php'; ?>