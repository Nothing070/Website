<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();

$page_title = 'Dashboard';

// Statistik
$total_kas = hitung_total_kas($conn);
$total_anggota = hitung_anggota_aktif($conn);
$kegiatan_bulan_ini = hitung_kegiatan_bulan_ini($conn);

// Total kegiatan
$total_kegiatan_query = "SELECT COUNT(*) as total FROM kegiatan";
$total_kegiatan_result = mysqli_query($conn, $total_kegiatan_query);
$total_kegiatan = mysqli_fetch_assoc($total_kegiatan_result)['total'];

// Transaksi terbaru
$transaksi_query = "SELECT k.*, u.nama_lengkap 
                    FROM keuangan k 
                    LEFT JOIN users u ON k.dibuat_oleh = u.id 
                    ORDER BY k.tanggal DESC, k.created_at DESC 
                    LIMIT 5";
$transaksi_result = mysqli_query($conn, $transaksi_query);

// Kegiatan mendatang
$kegiatan_query = "SELECT k.*, u.nama_lengkap 
                   FROM kegiatan k 
                   LEFT JOIN users u ON k.penanggung_jawab = u.id 
                   WHERE k.tanggal_mulai >= CURDATE() 
                   ORDER BY k.tanggal_mulai ASC 
                   LIMIT 5";
$kegiatan_result = mysqli_query($conn, $kegiatan_query);

// Data untuk chart keuangan (6 bulan terakhir)
$chart_query = "SELECT 
                    DATE_FORMAT(tanggal, '%Y-%m') as bulan,
                    SUM(CASE WHEN jenis_transaksi = 'masuk' THEN jumlah ELSE 0 END) as pemasukan,
                    SUM(CASE WHEN jenis_transaksi = 'keluar' THEN jumlah ELSE 0 END) as pengeluaran
                FROM keuangan 
                WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                GROUP BY DATE_FORMAT(tanggal, '%Y-%m')
                ORDER BY bulan ASC";
$chart_result = mysqli_query($conn, $chart_query);

$chart_labels = [];
$chart_pemasukan = [];
$chart_pengeluaran = [];

while ($row = mysqli_fetch_assoc($chart_result)) {
    $chart_labels[] = date('M Y', strtotime($row['bulan'] . '-01'));
    $chart_pemasukan[] = $row['pemasukan'];
    $chart_pengeluaran[] = $row['pengeluaran'];
}

include 'includes/header.php';
?>

<!-- Stats Cards -->
<div class="stats-cards">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-wallet"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo format_rupiah($total_kas); ?></h3>
            <p>Total Kas</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $total_anggota; ?></h3>
            <p>Anggota Aktif</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon orange">
            <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $kegiatan_bulan_ini; ?></h3>
            <p>Kegiatan Bulan Ini</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon red">
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $total_kegiatan; ?></h3>
            <p>Total Kegiatan</p>
        </div>
    </div>
</div>

<!-- Chart Keuangan -->
<div class="card">
    <div class="card-header">
        <h4><i class="fas fa-chart-bar"></i> Grafik Keuangan (6 Bulan Terakhir)</h4>
    </div>
    <canvas id="chartKeuangan" height="80"></canvas>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px;">
    <!-- Transaksi Terbaru -->
    <div class="card">
        <div class="card-header">
            <h4><i class="fas fa-money-bill-wave"></i> Transaksi Terbaru</h4>
            <a href="keuangan.php" class="btn btn-primary btn-sm">Lihat Semua</a>
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Jumlah</th>
                        <th>Jenis</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($transaksi_result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($transaksi_result)): ?>
                        <tr>
                            <td><?php echo format_tanggal($row['tanggal']); ?></td>
                            <td><?php echo $row['deskripsi']; ?></td>
                            <td><?php echo format_rupiah($row['jumlah']); ?></td>
                            <td>
                                <?php if ($row['jenis_transaksi'] == 'masuk'): ?>
                                    <span class="badge badge-success">Masuk</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Keluar</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center;">Belum ada transaksi</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Kegiatan Mendatang -->
    <div class="card">
        <div class="card-header">
            <h4><i class="fas fa-calendar-alt"></i> Kegiatan Mendatang</h4>
            <a href="kegiatan.php" class="btn btn-primary btn-sm">Lihat Semua</a>
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Kegiatan</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($kegiatan_result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($kegiatan_result)): ?>
                        <tr>
                            <td><?php echo $row['nama_kegiatan']; ?></td>
                            <td><?php echo format_tanggal($row['tanggal_mulai']); ?></td>
                            <td>
                                <?php 
                                $status_class = [
                                    'perencanaan' => 'badge-warning',
                                    'berlangsung' => 'badge-info',
                                    'selesai' => 'badge-success',
                                    'batal' => 'badge-danger'
                                ];
                                ?>
                                <span class="badge <?php echo $status_class[$row['status_kegiatan']]; ?>">
                                    <?php echo ucfirst($row['status_kegiatan']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" style="text-align: center;">Belum ada kegiatan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Chart Keuangan
    const ctx = document.getElementById('chartKeuangan').getContext('2d');
    const chartKeuangan = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($chart_labels); ?>,
            datasets: [{
                label: 'Pemasukan',
                data: <?php echo json_encode($chart_pemasukan); ?>,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Pengeluaran',
                data: <?php echo json_encode($chart_pengeluaran); ?>,
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
</script>

<?php include 'includes/footer.php'; ?>