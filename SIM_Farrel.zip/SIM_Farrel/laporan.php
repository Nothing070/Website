<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();

$page_title = 'Laporan';

// Filter
$jenis_laporan = isset($_GET['jenis']) ? $_GET['jenis'] : 'keuangan';
$periode_dari = isset($_GET['dari']) ? $_GET['dari'] : date('Y-m-01');
$periode_sampai = isset($_GET['sampai']) ? $_GET['sampai'] : date('Y-m-d');

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h4><i class="fas fa-file-alt"></i> Laporan</h4>
        <button onclick="printPage()" class="btn btn-primary btn-sm">
            <i class="fas fa-print"></i> Cetak Laporan
        </button>
    </div>
    
    <!-- Filter -->
    <div style="padding: 20px; background: #f9fafb; border-radius: 10px; margin-bottom: 20px;">
        <form method="GET" action="" style="display: flex; gap: 15px; flex-wrap: wrap; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label>Jenis Laporan</label>
                <select name="jenis" class="form-control" onchange="this.form.submit()">
                    <option value="keuangan" <?php echo $jenis_laporan == 'keuangan' ? 'selected' : ''; ?>>Laporan Keuangan</option>
                    <option value="kegiatan" <?php echo $jenis_laporan == 'kegiatan' ? 'selected' : ''; ?>>Laporan Kegiatan</option>
                    <option value="anggota" <?php echo $jenis_laporan == 'anggota' ? 'selected' : ''; ?>>Laporan Anggota</option>
                    <option value="iuran" <?php echo $jenis_laporan == 'iuran' ? 'selected' : ''; ?>>Laporan Iuran</option>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label>Dari Tanggal</label>
                <input type="date" name="dari" class="form-control" value="<?php echo $periode_dari; ?>">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label>Sampai Tanggal</label>
                <input type="date" name="sampai" class="form-control" value="<?php echo $periode_sampai; ?>">
            </div>
            
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-search"></i> Tampilkan
            </button>
        </form>
    </div>
</div>

<!-- Area Laporan -->
<div id="printArea">
    <!-- Header Laporan -->
    <div class="card" style="text-align: center; margin-bottom: 20px;">
        <h2 style="margin-bottom: 5px; color: var(--primary);">KARANG TARUNA</h2>
        <h3 style="margin-bottom: 10px;">
            <?php 
            $judul_laporan = [
                'keuangan' => 'LAPORAN KEUANGAN',
                'kegiatan' => 'LAPORAN KEGIATAN',
                'anggota' => 'LAPORAN DATA ANGGOTA',
                'iuran' => 'LAPORAN IURAN'
            ];
            echo $judul_laporan[$jenis_laporan];
            ?>
        </h3>
        <p style="margin: 0;">Periode: <?php echo format_tanggal($periode_dari); ?> s/d <?php echo format_tanggal($periode_sampai); ?></p>
    </div>

    <?php if ($jenis_laporan == 'keuangan'): ?>
        <!-- LAPORAN KEUANGAN -->
        <?php
        $query = "SELECT * FROM keuangan 
                  WHERE tanggal BETWEEN '$periode_dari' AND '$periode_sampai' 
                  ORDER BY tanggal ASC";
        $result = mysqli_query($conn, $query);
        
        $total_masuk = 0;
        $total_keluar = 0;
        ?>
        
        <div class="card">
            <h4 style="margin-bottom: 20px;"><i class="fas fa-chart-line"></i> Ringkasan Keuangan</h4>
            
            <?php
            $summary_query = "SELECT 
                             SUM(CASE WHEN jenis_transaksi = 'masuk' THEN jumlah ELSE 0 END) as total_masuk,
                             SUM(CASE WHEN jenis_transaksi = 'keluar' THEN jumlah ELSE 0 END) as total_keluar
                             FROM keuangan 
                             WHERE tanggal BETWEEN '$periode_dari' AND '$periode_sampai'";
            $summary = mysqli_fetch_assoc(mysqli_query($conn, $summary_query));
            $saldo = $summary['total_masuk'] - $summary['total_keluar'];
            ?>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px;">
                <div style="padding: 20px; background: #d1fae5; border-radius: 10px; text-align: center;">
                    <h3 style="color: #065f46; margin-bottom: 5px;"><?php echo format_rupiah($summary['total_masuk']); ?></h3>
                    <p style="color: #065f46; margin: 0;">Total Pemasukan</p>
                </div>
                <div style="padding: 20px; background: #fee2e2; border-radius: 10px; text-align: center;">
                    <h3 style="color: #991b1b; margin-bottom: 5px;"><?php echo format_rupiah($summary['total_keluar']); ?></h3>
                    <p style="color: #991b1b; margin: 0;">Total Pengeluaran</p>
                </div>
                <div style="padding: 20px; background: #dbeafe; border-radius: 10px; text-align: center;">
                    <h3 style="color: #1e40af; margin-bottom: 5px;"><?php echo format_rupiah($saldo); ?></h3>
                    <p style="color: #1e40af; margin: 0;">Saldo</p>
                </div>
            </div>
            
            <h4 style="margin-bottom: 15px;">Detail Transaksi</h4>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Kategori</th>
                            <th>Deskripsi</th>
                            <th>Pemasukan</th>
                            <th>Pengeluaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <?php
                                if ($row['jenis_transaksi'] == 'masuk') {
                                    $total_masuk += $row['jumlah'];
                                } else {
                                    $total_keluar += $row['jumlah'];
                                }
                                ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo format_tanggal($row['tanggal']); ?></td>
                                    <td><?php echo $row['kategori']; ?></td>
                                    <td><?php echo $row['deskripsi']; ?></td>
                                    <td style="color: #10b981; font-weight: 600;">
                                        <?php echo $row['jenis_transaksi'] == 'masuk' ? format_rupiah($row['jumlah']) : '-'; ?>
                                    </td>
                                    <td style="color: #ef4444; font-weight: 600;">
                                        <?php echo $row['jenis_transaksi'] == 'keluar' ? format_rupiah($row['jumlah']) : '-'; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            <tr style="background: #f3f4f6; font-weight: bold;">
                                <td colspan="4" style="text-align: right;">TOTAL</td>
                                <td style="color: #10b981;"><?php echo format_rupiah($total_masuk); ?></td>
                                <td style="color: #ef4444;"><?php echo format_rupiah($total_keluar); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center;">Tidak ada data transaksi</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Chart -->
            <div style="margin-top: 30px;">
                <h4 style="margin-bottom: 15px;">Grafik Keuangan Per Kategori</h4>
                <canvas id="chartKategori" height="100"></canvas>
            </div>
        </div>
        
        <?php
        // Data chart kategori
        $chart_query = "SELECT 
                        kategori,
                        SUM(CASE WHEN jenis_transaksi = 'masuk' THEN jumlah ELSE 0 END) as pemasukan,
                        SUM(CASE WHEN jenis_transaksi = 'keluar' THEN jumlah ELSE 0 END) as pengeluaran
                        FROM keuangan 
                        WHERE tanggal BETWEEN '$periode_dari' AND '$periode_sampai'
                        GROUP BY kategori";
        $chart_result = mysqli_query($conn, $chart_query);
        
        $categories = [];
        $pemasukan_data = [];
        $pengeluaran_data = [];
        
        while ($row = mysqli_fetch_assoc($chart_result)) {
            $categories[] = $row['kategori'];
            $pemasukan_data[] = $row['pemasukan'];
            $pengeluaran_data[] = $row['pengeluaran'];
        }
        ?>
        
        <script>
            const ctx = document.getElementById('chartKategori').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($categories); ?>,
                    datasets: [{
                        label: 'Pemasukan',
                        data: <?php echo json_encode($pemasukan_data); ?>,
                        backgroundColor: 'rgba(16, 185, 129, 0.7)',
                        borderColor: '#10b981',
                        borderWidth: 2
                    }, {
                        label: 'Pengeluaran',
                        data: <?php echo json_encode($pengeluaran_data); ?>,
                        backgroundColor: 'rgba(239, 68, 68, 0.7)',
                        borderColor: '#ef4444',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'Rp ' + value.toLocaleString('id-ID');
                                }
                            }
                        }
                    }
                }
            });
        </script>

    <?php elseif ($jenis_laporan == 'kegiatan'): ?>
        <!-- LAPORAN KEGIATAN -->
        <?php
        $query = "SELECT k.*, u.nama_lengkap, 
                  (SELECT COUNT(*) FROM peserta_kegiatan WHERE kegiatan_id = k.id) as jumlah_peserta
                  FROM kegiatan k 
                  LEFT JOIN users u ON k.penanggung_jawab = u.id
                  WHERE k.tanggal_mulai BETWEEN '$periode_dari' AND '$periode_sampai' 
                  ORDER BY k.tanggal_mulai ASC";
        $result = mysqli_query($conn, $query);
        
        $total_kegiatan = mysqli_num_rows($result);
        $total_anggaran = 0;
        ?>
        
        <div class="card">
            <h4 style="margin-bottom: 20px;"><i class="fas fa-calendar-alt"></i> Daftar Kegiatan</h4>
            
            <?php
            $stats_query = "SELECT 
                           COUNT(*) as total,
                           SUM(anggaran) as total_anggaran,
                           SUM(CASE WHEN status_kegiatan = 'selesai' THEN 1 ELSE 0 END) as selesai,
                           SUM(CASE WHEN status_kegiatan = 'berlangsung' THEN 1 ELSE 0 END) as berlangsung,
                           SUM(CASE WHEN status_kegiatan = 'perencanaan' THEN 1 ELSE 0 END) as perencanaan
                           FROM kegiatan 
                           WHERE tanggal_mulai BETWEEN '$periode_dari' AND '$periode_sampai'";
            $stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_query));
            ?>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
                <div style="padding: 15px; background: #dbeafe; border-radius: 10px; text-align: center;">
                    <h3 style="color: #1e40af;"><?php echo $stats['total']; ?></h3>
                    <p style="color: #1e40af; margin: 0; font-size: 14px;">Total Kegiatan</p>
                </div>
                <div style="padding: 15px; background: #d1fae5; border-radius: 10px; text-align: center;">
                    <h3 style="color: #065f46;"><?php echo $stats['selesai']; ?></h3>
                    <p style="color: #065f46; margin: 0; font-size: 14px;">Selesai</p>
                </div>
                <div style="padding: 15px; background: #fef3c7; border-radius: 10px; text-align: center;">
                    <h3 style="color: #92400e;"><?php echo $stats['berlangsung']; ?></h3>
                    <p style="color: #92400e; margin: 0; font-size: 14px;">Berlangsung</p>
                </div>
                <div style="padding: 15px; background: #f3f4f6; border-radius: 10px; text-align: center;">
                    <h3 style="color: #374151;"><?php echo $stats['perencanaan']; ?></h3>
                    <p style="color: #374151; margin: 0; font-size: 14px;">Perencanaan</p>
                </div>
            </div>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kegiatan</th>
                            <th>Tanggal</th>
                            <th>Tempat</th>
                            <th>Penanggung Jawab</th>
                            <th>Anggaran</th>
                            <th>Peserta</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <?php $total_anggaran += $row['anggaran']; ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><strong><?php echo $row['nama_kegiatan']; ?></strong></td>
                                    <td><?php echo format_tanggal($row['tanggal_mulai']); ?></td>
                                    <td><?php echo $row['tempat']; ?></td>
                                    <td><?php echo $row['nama_lengkap']; ?></td>
                                    <td><?php echo format_rupiah($row['anggaran']); ?></td>
                                    <td style="text-align: center;"><?php echo $row['jumlah_peserta']; ?> orang</td>
                                    <td>
                                        <?php 
                                        $status_class = [
                                            'perencanaan' => 'badge-warning',
                                            'berlangsung' => 'badge-info',
                                            'selesai' => 'badge-success',
                                            'batal' => 'badge-danger'
                                        ];
                                        ?>
                                        <span class="badge <?php echo $status_class[$row['status_kegiatan']]; ?>">
                                            <?php echo ucfirst($row['status_kegiatan']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            <tr style="background: #f3f4f6; font-weight: bold;">
                                <td colspan="5" style="text-align: right;">TOTAL ANGGARAN</td>
                                <td colspan="3"><?php echo format_rupiah($total_anggaran); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center;">Tidak ada data kegiatan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php elseif ($jenis_laporan == 'anggota'): ?>
        <!-- LAPORAN ANGGOTA -->
        <?php
        $query = "SELECT a.*, u.nama_lengkap, u.email, u.role 
                  FROM anggota a 
                  LEFT JOIN users u ON a.user_id = u.id
                  WHERE a.tanggal_bergabung BETWEEN '$periode_dari' AND '$periode_sampai'
                  ORDER BY u.nama_lengkap ASC";
        $result = mysqli_query($conn, $query);
        ?>
        
        <div class="card">
            <h4 style="margin-bottom: 20px;"><i class="fas fa-users"></i> Data Anggota</h4>
            
            <?php
            $stats_query = "SELECT 
                           COUNT(*) as total,
                           SUM(CASE WHEN status_anggota = 'aktif' THEN 1 ELSE 0 END) as aktif,
                           SUM(CASE WHEN status_anggota = 'non-aktif' THEN 1 ELSE 0 END) as non_aktif,
                           SUM(CASE WHEN jenis_kelamin = 'L' THEN 1 ELSE 0 END) as laki,
                           SUM(CASE WHEN jenis_kelamin = 'P' THEN 1 ELSE 0 END) as perempuan
                           FROM anggota a 
                           WHERE tanggal_bergabung BETWEEN '$periode_dari' AND '$periode_sampai'";
            $stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_query));
            ?>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
                <div style="padding: 15px; background: #dbeafe; border-radius: 10px; text-align: center;">
                    <h3 style="color: #1e40af;"><?php echo $stats['total']; ?></h3>
                    <p style="color: #1e40af; margin: 0; font-size: 14px;">Total Anggota</p>
                </div>
                <div style="padding: 15px; background: #d1fae5; border-radius: 10px; text-align: center;">
                    <h3 style="color: #065f46;"><?php echo $stats['aktif']; ?></h3>
                    <p style="color: #065f46; margin: 0; font-size: 14px;">Aktif</p>
                </div>
                <div style="padding: 15px; background: #fef3c7; border-radius: 10px; text-align: center;">
                    <h3 style="color: #92400e;"><?php echo $stats['laki']; ?></h3>
                    <p style="color: #92400e; margin: 0; font-size: 14px;">Laki-laki</p>
                </div>
                <div style="padding: 15px; background: #fee2e2; border-radius: 10px; text-align: center;">
                    <h3 style="color: #991b1b;"><?php echo $stats['perempuan']; ?></h3>
                    <p style="color: #991b1b; margin: 0; font-size: 14px;">Perempuan</p>
                </div>
            </div>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Lengkap</th>
                            <th>NIK</th>
                            <th>Jenis Kelamin</th>
                            <th>No. Telp</th>
                            <th>Pekerjaan</th>
                            <th>Role</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                                    <td><?php echo $row['nik']; ?></td>
                                    <td><?php echo $row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                                    <td><?php echo $row['no_telp']; ?></td>
                                    <td><?php echo $row['pekerjaan']; ?></td>
                                    <td><?php echo ucfirst($row['role']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $row['status_anggota'] == 'aktif' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo ucfirst($row['status_anggota']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center;">Tidak ada data anggota</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php else: ?>
        <!-- LAPORAN IURAN -->
        <?php
        $query = "SELECT i.*, u.nama_lengkap 
                  FROM iuran i 
                  LEFT JOIN users u ON i.user_id = u.id
                  WHERE i.tahun >= YEAR('$periode_dari') AND i.tahun <= YEAR('$periode_sampai')
                  ORDER BY i.tahun DESC, i.bulan DESC, u.nama_lengkap ASC";
        $result = mysqli_query($conn, $query);
        
        $total_tagihan = 0;
        $total_terbayar = 0;
        ?>
        
        <div class="card">
            <h4 style="margin-bottom: 20px;"><i class="fas fa-hand-holding-usd"></i> Data Iuran</h4>
            
            <?php
            $stats_query = "SELECT 
                           COUNT(*) as total,
                           SUM(jumlah) as total_tagihan,
                           SUM(CASE WHEN status_bayar = 'lunas' THEN 1 ELSE 0 END) as lunas,
                           SUM(CASE WHEN status_bayar = 'lunas' THEN jumlah ELSE 0 END) as total_terbayar
                           FROM iuran i 
                           WHERE tahun >= YEAR('$periode_dari') AND tahun <= YEAR('$periode_sampai')";
            $stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_query));
            ?>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
                <div style="padding: 15px; background: #dbeafe; border-radius: 10px; text-align: center;">
                    <h3 style="color: #1e40af;"><?php echo $stats['total']; ?></h3>
                    <p style="color: #1e40af; margin: 0; font-size: 14px;">Total Tagihan</p>
                </div>
                <div style="padding: 15px; background: #d1fae5; border-radius: 10px; text-align: center;">
                    <h3 style="color: #065f46;"><?php echo $stats['lunas']; ?></h3>
                    <p style="color: #065f46; margin: 0; font-size: 14px;">Lunas</p>
                </div>
                <div style="padding: 15px; background: #fef3c7; border-radius: 10px; text-align: center;">
                    <h3 style="color: #92400e;"><?php echo format_rupiah($stats['total_tagihan']); ?></h3>
                    <p style="color: #92400e; margin: 0; font-size: 14px;">Total Tagihan</p>
                </div>
                <div style="padding: 15px; background: #d1fae5; border-radius: 10px; text-align: center;">
                    <h3 style="color: #065f46;"><?php echo format_rupiah($stats['total_terbayar']); ?></h3>
                    <p style="color: #065f46; margin: 0; font-size: 14px;">Terbayar</p>
                </div>
            </div>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Anggota</th>
                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                            <th>Tanggal Bayar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <?php
                                $total_tagihan += $row['jumlah'];
                                if ($row['status_bayar'] == 'lunas') {
                                    $total_terbayar += $row['jumlah'];
                                }
                                ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                                    <td><?php echo $row['bulan']; ?></td>
                                    <td><?php echo $row['tahun']; ?></td>
                                    <td><?php echo format_rupiah($row['jumlah']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $row['status_bayar'] == 'lunas' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo $row['status_bayar'] == 'lunas' ? 'Lunas' : 'Belum Bayar'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $row['tanggal_bayar'] ? format_tanggal($row['tanggal_bayar']) : '-'; ?></td>
                                </tr>
                            <?php endwhile; ?>
                            <tr style="background: #f3f4f6; font-weight: bold;">
                                <td colspan="4" style="text-align: right;">TOTAL</td>
                                <td><?php echo format_rupiah($total_tagihan); ?></td>
                                <td colspan="2">Terbayar: <?php echo format_rupiah($total_terbayar); ?></td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align: center;">Tidak ada data iuran</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Footer Laporan -->
    <div class="card" style="text-align: right; margin-top: 30px;">
        <p style="margin-bottom: 60px;">Dicetak pada: <?php echo date('d-m-Y H:i:s'); ?></p>
        <div style="display: inline-block; text-align: center;">
            <p style="margin-bottom: 60px;">(_______________________)</p>
            <p style="margin: 0; font-weight: bold;">Ketua Karang Taruna</p>
        </div>
    </div>
</div>

<style>
@media print {
    .sidebar, .topbar, .card-header button, 
    .pagination, form {
        display: none !important;
    }
    
    .main-content {
        margin-left: 0 !important;
    }
    
    body {
        background: white !important;
    }
    
    .card {
        box-shadow: none !important;
        page-break-inside: avoid;
    }
}
</style>

<?php include 'includes/footer.php'; ?>