<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();
cek_role(['admin', 'bendahara']);

$page_title = 'Keuangan';

// Proses tambah transaksi
if (isset($_POST['tambah_transaksi'])) {
    $tanggal = esc($_POST['tanggal']);
    $jenis_transaksi = esc($_POST['jenis_transaksi']);
    $kategori = esc($_POST['kategori']);
    $deskripsi = esc($_POST['deskripsi']);
    $jumlah = esc($_POST['jumlah']);
    $kegiatan_id = !empty($_POST['kegiatan_id']) ? esc($_POST['kegiatan_id']) : 'NULL';
    $dibuat_oleh = $_SESSION['user_id'];
    
    // Upload bukti transaksi
    $bukti_transaksi = '';
    if (isset($_FILES['bukti_transaksi']) && $_FILES['bukti_transaksi']['error'] == 0) {
        $bukti_transaksi = upload_file($_FILES['bukti_transaksi'], BUKTI_TRANSAKSI_DIR);
    }
    
    $query = "INSERT INTO keuangan (tanggal, jenis_transaksi, kategori, deskripsi, jumlah, kegiatan_id, dibuat_oleh, bukti_transaksi) 
              VALUES ('$tanggal', '$jenis_transaksi', '$kategori', '$deskripsi', '$jumlah', $kegiatan_id, '$dibuat_oleh', '$bukti_transaksi')";
    
    if (mysqli_query($conn, $query)) {
        set_alert('success', 'Transaksi berhasil ditambahkan!');
    } else {
        set_alert('danger', 'Gagal menambahkan transaksi!');
    }
    header('Location: keuangan.php');
    exit();
}

// Proses hapus transaksi
if (isset($_GET['hapus'])) {
    $id = esc($_GET['hapus']);
    
    // Hapus bukti transaksi jika ada
    $get_bukti = mysqli_query($conn, "SELECT bukti_transaksi FROM keuangan WHERE id = '$id'");
    $bukti_data = mysqli_fetch_assoc($get_bukti);
    if ($bukti_data['bukti_transaksi']) {
        hapus_file(BUKTI_TRANSAKSI_DIR . $bukti_data['bukti_transaksi']);
    }
    
    $query = "DELETE FROM keuangan WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        set_alert('success', 'Transaksi berhasil dihapus!');
    } else {
        set_alert('danger', 'Gagal menghapus transaksi!');
    }
    header('Location: keuangan.php');
    exit();
}

// Filter
$filter_jenis = isset($_GET['jenis']) ? $_GET['jenis'] : '';
$filter_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$where = "WHERE 1=1";
if ($filter_jenis) {
    $where .= " AND k.jenis_transaksi = '$filter_jenis'";
}
if ($filter_bulan) {
    $where .= " AND DATE_FORMAT(k.tanggal, '%Y-%m') = '$filter_bulan'";
}
if ($search) {
    $where .= " AND (k.deskripsi LIKE '%$search%' OR k.kategori LIKE '%$search%')";
}

// Pagination
$per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Hitung total data
$count_query = "SELECT COUNT(*) as total FROM keuangan k $where";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];

// Ambil data transaksi
$query = "SELECT k.*, u.nama_lengkap, kg.nama_kegiatan 
          FROM keuangan k 
          LEFT JOIN users u ON k.dibuat_oleh = u.id 
          LEFT JOIN kegiatan kg ON k.kegiatan_id = kg.id 
          $where
          ORDER BY k.tanggal DESC, k.created_at DESC 
          LIMIT $per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

// Hitung total pemasukan dan pengeluaran
$total_query = "SELECT 
                SUM(CASE WHEN jenis_transaksi = 'masuk' THEN jumlah ELSE 0 END) as total_masuk,
                SUM(CASE WHEN jenis_transaksi = 'keluar' THEN jumlah ELSE 0 END) as total_keluar
                FROM keuangan k $where";
$total_result = mysqli_query($conn, $total_query);
$total_data_keuangan = mysqli_fetch_assoc($total_result);

// Data kegiatan untuk dropdown
$kegiatan_query = "SELECT id, nama_kegiatan FROM kegiatan ORDER BY nama_kegiatan ASC";
$kegiatan_result = mysqli_query($conn, $kegiatan_query);

include 'includes/header.php';
?>

<!-- Summary Cards -->
<div class="stats-cards">
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-arrow-down"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo format_rupiah($total_data_keuangan['total_masuk']); ?></h3>
            <p>Total Pemasukan</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon red">
            <i class="fas fa-arrow-up"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo format_rupiah($total_data_keuangan['total_keluar']); ?></h3>
            <p>Total Pengeluaran</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-balance-scale"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo format_rupiah($total_data_keuangan['total_masuk'] - $total_data_keuangan['total_keluar']); ?></h3>
            <p>Saldo</p>
        </div>
    </div>
</div>

<!-- Filter & Tambah -->
<div class="card">
    <div class="card-header">
        <h4><i class="fas fa-money-bill-wave"></i> Data Transaksi Keuangan</h4>
        <button class="btn btn-primary btn-sm" onclick="openModal('modalTambah')">
            <i class="fas fa-plus"></i> Tambah Transaksi
        </button>
    </div>
    
    <!-- Filter -->
    <div style="padding: 20px; background: #f9fafb; border-radius: 10px; margin-bottom: 20px;">
        <form method="GET" action="" style="display: flex; gap: 15px; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 200px;">
                <input type="text" name="search" class="form-control" placeholder="Cari deskripsi..." 
                       value="<?php echo $search; ?>">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <select name="jenis" class="form-control">
                    <option value="">Semua Jenis</option>
                    <option value="masuk" <?php echo $filter_jenis == 'masuk' ? 'selected' : ''; ?>>Pemasukan</option>
                    <option value="keluar" <?php echo $filter_jenis == 'keluar' ? 'selected' : ''; ?>>Pengeluaran</option>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <input type="month" name="bulan" class="form-control" value="<?php echo $filter_bulan; ?>">
            </div>
            
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-filter"></i> Filter
            </button>
            
            <a href="keuangan.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-redo"></i> Reset
            </a>
        </form>
    </div>
    
    <!-- Tabel -->
    <div class="table-responsive">
        <table id="tableKeuangan">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Deskripsi</th>
                    <th>Kegiatan</th>
                    <th>Jumlah</th>
                    <th>Jenis</th>
                    <th>Dibuat Oleh</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = $offset + 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo format_tanggal($row['tanggal']); ?></td>
                        <td><?php echo $row['kategori']; ?></td>
                        <td><?php echo $row['deskripsi']; ?></td>
                        <td><?php echo $row['nama_kegiatan'] ?? '-'; ?></td>
                        <td><strong><?php echo format_rupiah($row['jumlah']); ?></strong></td>
                        <td>
                            <?php if ($row['jenis_transaksi'] == 'masuk'): ?>
                                <span class="badge badge-success">Masuk</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Keluar</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $row['nama_lengkap']; ?></td>
                        <td>
                            <?php if ($row['bukti_transaksi']): ?>
                                <a href="<?php echo BUKTI_TRANSAKSI_DIR . $row['bukti_transaksi']; ?>" 
                                   target="_blank" class="btn btn-sm" style="background: #10b981; color: white;" 
                                   title="Lihat Bukti">
                                    <i class="fas fa-file"></i>
                                </a>
                            <?php endif; ?>
                            <a href="?hapus=<?php echo $row['id']; ?>" 
                               onclick="return confirmDelete()" 
                               class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" style="text-align: center;">Tidak ada data transaksi</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php echo pagination($total_data, $per_page, $page, 'keuangan.php'); ?>
</div>

<!-- Modal Tambah Transaksi -->
<div id="modalTambah" class="modal">
    <div class="modal-content">
        <span class="close-modal" onclick="closeModal('modalTambah')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-plus"></i> Tambah Transaksi</h3>
        
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label>Tanggal *</label>
                <input type="date" name="tanggal" class="form-control" required 
                       value="<?php echo date('Y-m-d'); ?>">
            </div>
            
            <div class="form-group">
                <label>Jenis Transaksi *</label>
                <select name="jenis_transaksi" class="form-control" required>
                    <option value="masuk">Pemasukan</option>
                    <option value="keluar">Pengeluaran</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Kategori *</label>
                <select name="kategori" class="form-control" required>
                    <option value="Iuran Bulanan">Iuran Bulanan</option>
                    <option value="Donasi">Donasi</option>
                    <option value="Kegiatan">Kegiatan</option>
                    <option value="Operasional">Operasional</option>
                    <option value="Lain-lain">Lain-lain</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Kegiatan (Opsional)</label>
                <select name="kegiatan_id" class="form-control">
                    <option value="">-- Pilih Kegiatan --</option>
                    <?php while ($kg = mysqli_fetch_assoc($kegiatan_result)): ?>
                        <option value="<?php echo $kg['id']; ?>"><?php echo $kg['nama_kegiatan']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Deskripsi *</label>
                <textarea name="deskripsi" class="form-control" rows="3" required 
                          placeholder="Masukkan deskripsi transaksi"></textarea>
            </div>
            
            <div class="form-group">
                <label>Jumlah (Rp) *</label>
                <input type="number" name="jumlah" class="form-control" required 
                       placeholder="0" min="0">
            </div>
            
            <div class="form-group">
                <label>Bukti Transaksi (Opsional)</label>
                <input type="file" name="bukti_transaksi" class="form-control" 
                       accept="image/*,.pdf">
                <small style="color: #6b7280;">Format: JPG, PNG, PDF (Max 5MB)</small>
            </div>
            
            <button type="submit" name="tambah_transaksi" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Transaksi
            </button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>