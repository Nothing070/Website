<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();

$page_title = 'Kegiatan';

// Proses tambah kegiatan
if (isset($_POST['tambah_kegiatan'])) {
    $nama_kegiatan = esc($_POST['nama_kegiatan']);
    $deskripsi = esc($_POST['deskripsi']);
    $tanggal_mulai = esc($_POST['tanggal_mulai']);
    $tanggal_selesai = esc($_POST['tanggal_selesai']);
    $tempat = esc($_POST['tempat']);
    $penanggung_jawab = esc($_POST['penanggung_jawab']);
    $anggaran = esc($_POST['anggaran']);
    $status_kegiatan = esc($_POST['status_kegiatan']);
    
    // Upload foto kegiatan
    $foto_kegiatan = '';
    if (isset($_FILES['foto_kegiatan']) && $_FILES['foto_kegiatan']['error'] == 0) {
        $foto_kegiatan = upload_file($_FILES['foto_kegiatan'], FOTO_KEGIATAN_DIR);
    }
    
    $query = "INSERT INTO kegiatan (nama_kegiatan, deskripsi, tanggal_mulai, tanggal_selesai, tempat, penanggung_jawab, anggaran, status_kegiatan, foto_kegiatan) 
              VALUES ('$nama_kegiatan', '$deskripsi', '$tanggal_mulai', '$tanggal_selesai', '$tempat', '$penanggung_jawab', '$anggaran', '$status_kegiatan', '$foto_kegiatan')";
    
    if (mysqli_query($conn, $query)) {
        set_alert('success', 'Kegiatan berhasil ditambahkan!');
    } else {
        set_alert('danger', 'Gagal menambahkan kegiatan!');
    }
    header('Location: kegiatan.php');
    exit();
}

// Proses hapus kegiatan
if (isset($_GET['hapus'])) {
    $id = esc($_GET['hapus']);
    
    // Hapus foto kegiatan jika ada
    $get_foto = mysqli_query($conn, "SELECT foto_kegiatan FROM kegiatan WHERE id = '$id'");
    $foto_data = mysqli_fetch_assoc($get_foto);
    if ($foto_data['foto_kegiatan']) {
        hapus_file(FOTO_KEGIATAN_DIR . $foto_data['foto_kegiatan']);
    }
    
    $query = "DELETE FROM kegiatan WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        set_alert('success', 'Kegiatan berhasil dihapus!');
    } else {
        set_alert('danger', 'Gagal menghapus kegiatan!');
    }
    header('Location: kegiatan.php');
    exit();
}

// Proses update status kegiatan
if (isset($_POST['update_status'])) {
    $id = esc($_POST['kegiatan_id']);
    $status = esc($_POST['status']);
    
    $query = "UPDATE kegiatan SET status_kegiatan = '$status' WHERE id = '$id'";
    if (mysqli_query($conn, $query)) {
        set_alert('success', 'Status kegiatan berhasil diupdate!');
    }
    header('Location: kegiatan.php');
    exit();
}

// Filter
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

$where = "WHERE 1=1";
if ($filter_status) {
    $where .= " AND k.status_kegiatan = '$filter_status'";
}
if ($search) {
    $where .= " AND k.nama_kegiatan LIKE '%$search%'";
}

// Pagination
$per_page = 6;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Hitung total data
$count_query = "SELECT COUNT(*) as total FROM kegiatan k $where";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];

// Ambil data kegiatan
$query = "SELECT k.*, u.nama_lengkap 
          FROM kegiatan k 
          LEFT JOIN users u ON k.penanggung_jawab = u.id 
          $where
          ORDER BY k.tanggal_mulai DESC 
          LIMIT $per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

// Data users untuk penanggung jawab
$users_query = "SELECT id, nama_lengkap FROM users WHERE role IN ('admin', 'ketua', 'sekretaris', 'bendahara') ORDER BY nama_lengkap ASC";
$users_result = mysqli_query($conn, $users_query);

include 'includes/header.php';
?>

<!-- Filter & Tambah -->
<div class="card">
    <div class="card-header">
        <h4><i class="fas fa-calendar-alt"></i> Data Kegiatan</h4>
        <?php if (in_array($_SESSION['role'], ['admin', 'ketua'])): ?>
        <button class="btn btn-primary btn-sm" onclick="openModal('modalTambah')">
            <i class="fas fa-plus"></i> Tambah Kegiatan
        </button>
        <?php endif; ?>
    </div>
    
    <!-- Filter -->
    <div style="padding: 20px; background: #f9fafb; border-radius: 10px; margin-bottom: 20px;">
        <form method="GET" action="" style="display: flex; gap: 15px; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; flex: 1; min-width: 200px;">
                <input type="text" name="search" class="form-control" placeholder="Cari nama kegiatan..." 
                       value="<?php echo $search; ?>">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <select name="status" class="form-control">
                    <option value="">Semua Status</option>
                    <option value="perencanaan" <?php echo $filter_status == 'perencanaan' ? 'selected' : ''; ?>>Perencanaan</option>
                    <option value="berlangsung" <?php echo $filter_status == 'berlangsung' ? 'selected' : ''; ?>>Berlangsung</option>
                    <option value="selesai" <?php echo $filter_status == 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                    <option value="batal" <?php echo $filter_status == 'batal' ? 'selected' : ''; ?>>Batal</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-filter"></i> Filter
            </button>
            
            <a href="kegiatan.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-redo"></i> Reset
            </a>
        </form>
    </div>
</div>

<!-- Grid Kegiatan -->
<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px;">
    <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="card" style="overflow: hidden;">
            <!-- Foto Kegiatan -->
            <?php if ($row['foto_kegiatan']): ?>
            <img src="<?php echo FOTO_KEGIATAN_DIR . $row['foto_kegiatan']; ?>" 
                 style="width: 100%; height: 200px; object-fit: cover;" 
                 alt="<?php echo $row['nama_kegiatan']; ?>"
                 onerror="this.src='assets/img/default-event.jpg'">
            <?php else: ?>
            <div style="width: 100%; height: 200px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-calendar-alt" style="font-size: 60px; color: white; opacity: 0.7;"></i>
            </div>
            <?php endif; ?>
            
            <div style="padding: 20px;">
                <h3 style="font-size: 18px; margin-bottom: 10px;"><?php echo $row['nama_kegiatan']; ?></h3>
                
                <?php 
                $status_class = [
                    'perencanaan' => 'badge-warning',
                    'berlangsung' => 'badge-info',
                    'selesai' => 'badge-success',
                    'batal' => 'badge-danger'
                ];
                ?>
                <span class="badge <?php echo $status_class[$row['status_kegiatan']]; ?>" style="margin-bottom: 15px;">
                    <?php echo ucfirst($row['status_kegiatan']); ?>
                </span>
                
                <p style="color: #6b7280; font-size: 14px; margin-bottom: 15px; line-height: 1.6;">
                    <?php echo substr($row['deskripsi'], 0, 100) . (strlen($row['deskripsi']) > 100 ? '...' : ''); ?>
                </p>
                
                <div style="border-top: 1px solid #e5e7eb; padding-top: 15px; margin-top: 15px;">
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <i class="fas fa-calendar" style="color: var(--primary);"></i>
                        <span style="font-size: 14px;"><?php echo format_tanggal($row['tanggal_mulai']); ?></span>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <i class="fas fa-map-marker-alt" style="color: var(--primary);"></i>
                        <span style="font-size: 14px;"><?php echo $row['tempat']; ?></span>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <i class="fas fa-user-tie" style="color: var(--primary);"></i>
                        <span style="font-size: 14px;"><?php echo $row['nama_lengkap']; ?></span>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <i class="fas fa-money-bill-wave" style="color: var(--primary);"></i>
                        <span style="font-size: 14px; font-weight: 600;"><?php echo format_rupiah($row['anggaran']); ?></span>
                    </div>
                </div>
                
                <?php if (in_array($_SESSION['role'], ['admin', 'ketua'])): ?>
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button onclick="openModalStatus(<?php echo $row['id']; ?>, '<?php echo $row['status_kegiatan']; ?>')" 
                            class="btn btn-sm" style="flex: 1; background: var(--secondary); color: white;">
                        <i class="fas fa-edit"></i> Status
                    </button>
                    <a href="?hapus=<?php echo $row['id']; ?>" 
                       onclick="return confirmDelete()" 
                       class="btn btn-danger btn-sm" style="flex: 1;">
                        <i class="fas fa-trash"></i> Hapus
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 40px;">
            <i class="fas fa-calendar-times" style="font-size: 60px; color: #d1d5db; margin-bottom: 20px;"></i>
            <p style="color: #6b7280;">Tidak ada data kegiatan</p>
        </div>
    <?php endif; ?>
</div>

<!-- Pagination -->
<?php echo pagination($total_data, $per_page, $page, 'kegiatan.php'); ?>

<!-- Modal Tambah Kegiatan -->
<div id="modalTambah" class="modal">
    <div class="modal-content" style="max-width: 700px;">
        <span class="close-modal" onclick="closeModal('modalTambah')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-plus"></i> Tambah Kegiatan</h3>
        
        <form method="POST" action="" enctype="multipart/form-data">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>Nama Kegiatan *</label>
                    <input type="text" name="nama_kegiatan" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tempat *</label>
                    <input type="text" name="tempat" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tanggal Mulai *</label>
                    <input type="date" name="tanggal_mulai" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Penanggung Jawab *</label>
                    <select name="penanggung_jawab" class="form-control" required>
                        <option value="">-- Pilih --</option>
                        <?php while ($user = mysqli_fetch_assoc($users_result)): ?>
                            <option value="<?php echo $user['id']; ?>"><?php echo $user['nama_lengkap']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Anggaran (Rp) *</label>
                    <input type="number" name="anggaran" class="form-control" required min="0">
                </div>
                
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status_kegiatan" class="form-control" required>
                        <option value="perencanaan">Perencanaan</option>
                        <option value="berlangsung">Berlangsung</option>
                        <option value="selesai">Selesai</option>
                        <option value="batal">Batal</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Foto Kegiatan</label>
                    <input type="file" name="foto_kegiatan" class="form-control" accept="image/*">
                </div>
            </div>
            
            <div class="form-group">
                <label>Deskripsi *</label>
                <textarea name="deskripsi" class="form-control" rows="4" required></textarea>
            </div>
            
            <button type="submit" name="tambah_kegiatan" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Kegiatan
            </button>
        </form>
    </div>
</div>

<!-- Modal Update Status -->
<div id="modalStatus" class="modal">
    <div class="modal-content" style="max-width: 400px;">
        <span class="close-modal" onclick="closeModal('modalStatus')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-edit"></i> Update Status Kegiatan</h3>
        
        <form method="POST" action="">
            <input type="hidden" name="kegiatan_id" id="status_kegiatan_id">
            
            <div class="form-group">
                <label>Status Kegiatan *</label>
                <select name="status" id="status_value" class="form-control" required>
                    <option value="perencanaan">Perencanaan</option>
                    <option value="berlangsung">Berlangsung</option>
                    <option value="selesai">Selesai</option>
                    <option value="batal">Batal</option>
                </select>
            </div>
            
            <button type="submit" name="update_status" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Status
            </button>
        </form>
    </div>
</div>

<script>
function openModalStatus(id, status) {
    document.getElementById('status_kegiatan_id').value = id;
    document.getElementById('status_value').value = status;
    openModal('modalStatus');
}
</script>

<?php include 'includes/footer.php'; ?>