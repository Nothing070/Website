<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();
cek_role(['admin', 'bendahara']);

$page_title = 'Iuran Anggota';

// Proses bayar iuran
if (isset($_POST['bayar_iuran'])) {
    $iuran_id = esc($_POST['iuran_id']);
    $tanggal_bayar = date('Y-m-d');
    
    $query = "UPDATE iuran SET status_bayar = 'lunas', tanggal_bayar = '$tanggal_bayar' WHERE id = '$iuran_id'";
    
    if (mysqli_query($conn, $query)) {
        // Tambah ke keuangan
        $iuran_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM iuran WHERE id = '$iuran_id'"));
        $deskripsi = "Iuran {$iuran_data['bulan']} {$iuran_data['tahun']}";
        
        $keuangan_query = "INSERT INTO keuangan (tanggal, jenis_transaksi, kategori, deskripsi, jumlah, dibuat_oleh) 
                          VALUES ('$tanggal_bayar', 'masuk', 'Iuran Bulanan', '$deskripsi', '{$iuran_data['jumlah']}', '{$_SESSION['user_id']}')";
        mysqli_query($conn, $keuangan_query);
        
        set_alert('success', 'Iuran berhasil dibayar!');
    }
    header('Location: iuran.php');
    exit();
}

// Proses generate iuran bulanan
if (isset($_POST['generate_iuran'])) {
    $bulan = esc($_POST['bulan']);
    $tahun = esc($_POST['tahun']);
    $jumlah = esc($_POST['jumlah']);
    
    // Ambil semua anggota aktif
    $anggota_query = "SELECT user_id FROM anggota WHERE status_anggota = 'aktif'";
    $anggota_result = mysqli_query($conn, $anggota_query);
    
    $success = 0;
    while ($anggota = mysqli_fetch_assoc($anggota_result)) {
        // Cek apakah sudah ada iuran untuk bulan dan tahun ini
        $check = mysqli_query($conn, "SELECT * FROM iuran WHERE user_id = '{$anggota['user_id']}' AND bulan = '$bulan' AND tahun = '$tahun'");
        
        if (mysqli_num_rows($check) == 0) {
            $insert = "INSERT INTO iuran (user_id, bulan, tahun, jumlah) VALUES ('{$anggota['user_id']}', '$bulan', '$tahun', '$jumlah')";
            if (mysqli_query($conn, $insert)) {
                $success++;
            }
        }
    }
    
    set_alert('success', "Berhasil generate $success iuran untuk bulan $bulan $tahun");
    header('Location: iuran.php');
    exit();
}

// Filter
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$filter_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$filter_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

$where = "WHERE 1=1";
if ($filter_status) {
    $where .= " AND i.status_bayar = '$filter_status'";
}
if ($filter_bulan) {
    $where .= " AND i.bulan = '$filter_bulan'";
}
if ($filter_tahun) {
    $where .= " AND i.tahun = '$filter_tahun'";
}

// Pagination
$per_page = 15;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $per_page;

// Hitung total data
$count_query = "SELECT COUNT(*) as total FROM iuran i $where";
$count_result = mysqli_query($conn, $count_query);
$total_data = mysqli_fetch_assoc($count_result)['total'];

// Ambil data iuran
$query = "SELECT i.*, u.nama_lengkap 
          FROM iuran i 
          LEFT JOIN users u ON i.user_id = u.id 
          $where
          ORDER BY i.tahun DESC, i.bulan DESC, u.nama_lengkap ASC 
          LIMIT $per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

// Statistik iuran
$stats_query = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status_bayar = 'lunas' THEN 1 ELSE 0 END) as lunas,
                SUM(CASE WHEN status_bayar = 'belum' THEN 1 ELSE 0 END) as belum,
                SUM(CASE WHEN status_bayar = 'lunas' THEN jumlah ELSE 0 END) as total_terkumpul
                FROM iuran i $where";
$stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_query));

include 'includes/header.php';
?>

<!-- Stats -->
<div class="stats-cards">
    <div class="stat-card">
        <div class="stat-icon blue">
            <i class="fas fa-list"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['total']; ?></h3>
            <p>Total Tagihan</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['lunas']; ?></h3>
            <p>Sudah Lunas</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon red">
            <i class="fas fa-exclamation-circle"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo $stats['belum']; ?></h3>
            <p>Belum Bayar</p>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon orange">
            <i class="fas fa-money-bill-wave"></i>
        </div>
        <div class="stat-info">
            <h3><?php echo format_rupiah($stats['total_terkumpul']); ?></h3>
            <p>Total Terkumpul</p>
        </div>
    </div>
</div>

<!-- Data Iuran -->
<div class="card">
    <div class="card-header">
        <h4><i class="fas fa-hand-holding-usd"></i> Data Iuran Anggota</h4>
        <button class="btn btn-primary btn-sm" onclick="openModal('modalGenerate')">
            <i class="fas fa-cog"></i> Generate Iuran
        </button>
    </div>
    
    <!-- Filter -->
    <div style="padding: 20px; background: #f9fafb; border-radius: 10px; margin-bottom: 20px;">
        <form method="GET" action="" style="display: flex; gap: 15px; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0;">
                <select name="bulan" class="form-control">
                    <option value="">Semua Bulan</option>
                    <?php 
                    $bulan_list = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    foreach ($bulan_list as $b):
                    ?>
                        <option value="<?php echo $b; ?>" <?php echo $filter_bulan == $b ? 'selected' : ''; ?>><?php echo $b; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <select name="tahun" class="form-control">
                    <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                        <option value="<?php echo $y; ?>" <?php echo $filter_tahun == $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <select name="status" class="form-control">
                    <option value="">Semua Status</option>
                    <option value="lunas" <?php echo $filter_status == 'lunas' ? 'selected' : ''; ?>>Lunas</option>
                    <option value="belum" <?php echo $filter_status == 'belum' ? 'selected' : ''; ?>>Belum Bayar</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fas fa-filter"></i> Filter
            </button>
            
            <a href="iuran.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-redo"></i> Reset
            </a>
        </form>
    </div>
    
    <!-- Tabel -->
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Anggota</th>
                    <th>Bulan</th>
                    <th>Tahun</th>
                    <th>Jumlah</th>
                    <th>Status</th>
                    <th>Tanggal Bayar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php $no = $offset + 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><strong><?php echo $row['nama_lengkap']; ?></strong></td>
                        <td><?php echo $row['bulan']; ?></td>
                        <td><?php echo $row['tahun']; ?></td>
                        <td><strong><?php echo format_rupiah($row['jumlah']); ?></strong></td>
                        <td>
                            <?php if ($row['status_bayar'] == 'lunas'): ?>
                                <span class="badge badge-success">Lunas</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Belum Bayar</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $row['tanggal_bayar'] ? format_tanggal($row['tanggal_bayar']) : '-'; ?></td>
                        <td>
                            <?php if ($row['status_bayar'] == 'belum'): ?>
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="iuran_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="bayar_iuran" class="btn btn-sm" 
                                            style="background: var(--secondary); color: white;"
                                            onclick="return confirm('Konfirmasi pembayaran iuran?')">
                                        <i class="fas fa-check"></i> Bayar
                                    </button>
                                </form>
                            <?php else: ?>
                                <span style="color: var(--secondary);"><i class="fas fa-check-circle"></i> Sudah Bayar</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center;">Tidak ada data iuran</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination -->
    <?php echo pagination($total_data, $per_page, $page, 'iuran.php'); ?>
</div>

<!-- Modal Generate Iuran -->
<div id="modalGenerate" class="modal">
    <div class="modal-content" style="max-width: 500px;">
        <span class="close-modal" onclick="closeModal('modalGenerate')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-cog"></i> Generate Iuran Bulanan</h3>
        
        <div style="padding: 15px; background: #fef3c7; border-radius: 10px; margin-bottom: 20px;">
            <i class="fas fa-info-circle" style="color: #92400e;"></i>
            <small style="color: #92400e;">
                Generate iuran akan membuat tagihan untuk semua anggota aktif pada bulan dan tahun yang dipilih.
            </small>
        </div>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>Bulan *</label>
                <select name="bulan" class="form-control" required>
                    <?php 
                    $bulan_list = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    foreach ($bulan_list as $b):
                    ?>
                        <option value="<?php echo $b; ?>" <?php echo $b == date('F') ? 'selected' : ''; ?>><?php echo $b; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Tahun *</label>
                <select name="tahun" class="form-control" required>
                    <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                        <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Jumlah Iuran (Rp) *</label>
                <input type="number" name="jumlah" class="form-control" required 
                       placeholder="50000" value="50000" min="0">
            </div>
            
            <button type="submit" name="generate_iuran" class="btn btn-primary">
                <i class="fas fa-check"></i> Generate Iuran
            </button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>