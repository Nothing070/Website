<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();

$page_title = 'Notifikasi';

// Proses tandai sudah dibaca
if (isset($_GET['baca'])) {
    $id = esc($_GET['baca']);
    $query = "UPDATE notifikasi SET status_baca = 'sudah' WHERE id = '$id' AND user_id = '{$_SESSION['user_id']}'";
    mysqli_query($conn, $query);
    header('Location: notifikasi.php');
    exit();
}

// Proses tandai semua sudah dibaca
if (isset($_GET['baca_semua'])) {
    $query = "UPDATE notifikasi SET status_baca = 'sudah' WHERE user_id = '{$_SESSION['user_id']}'";
    mysqli_query($conn, $query);
    set_alert('success', 'Semua notifikasi ditandai sudah dibaca!');
    header('Location: notifikasi.php');
    exit();
}

// Proses hapus notifikasi
if (isset($_GET['hapus'])) {
    $id = esc($_GET['hapus']);
    $query = "DELETE FROM notifikasi WHERE id = '$id' AND user_id = '{$_SESSION['user_id']}'";
    mysqli_query($conn, $query);
    set_alert('success', 'Notifikasi berhasil dihapus!');
    header('Location: notifikasi.php');
    exit();
}

// Ambil data notifikasi
$query = "SELECT * FROM notifikasi 
          WHERE user_id = '{$_SESSION['user_id']}' 
          ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);

// Hitung notifikasi belum dibaca
$unread_query = "SELECT COUNT(*) as total FROM notifikasi 
                 WHERE user_id = '{$_SESSION['user_id']}' AND status_baca = 'belum'";
$unread_result = mysqli_query($conn, $unread_query);
$unread_count = mysqli_fetch_assoc($unread_result)['total'];

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h4>
            <i class="fas fa-bell"></i> Notifikasi 
            <?php if ($unread_count > 0): ?>
                <span class="badge badge-danger"><?php echo $unread_count; ?> Belum Dibaca</span>
            <?php endif; ?>
        </h4>
        <?php if ($unread_count > 0): ?>
        <a href="?baca_semua=true" class="btn btn-primary btn-sm">
            <i class="fas fa-check-double"></i> Tandai Semua Sudah Dibaca
        </a>
        <?php endif; ?>
    </div>
    
    <div style="padding: 20px;">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="card" style="margin-bottom: 15px; <?php echo $row['status_baca'] == 'belum' ? 'background: #eff6ff; border-left: 4px solid var(--primary);' : ''; ?>">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                                <i class="fas fa-bell" style="color: var(--primary); font-size: 20px;"></i>
                                <h4 style="margin: 0; color: var(--dark);"><?php echo $row['judul']; ?></h4>
                                <?php if ($row['status_baca'] == 'belum'): ?>
                                    <span class="badge badge-info">Baru</span>
                                <?php endif; ?>
                            </div>
                            <p style="color: #6b7280; margin-bottom: 10px; line-height: 1.6;">
                                <?php echo $row['pesan']; ?>
                            </p>
                            <small style="color: #9ca3af;">
                                <i class="fas fa-clock"></i>
                                <?php 
                                $timestamp = strtotime($row['created_at']);
                                $diff = time() - $timestamp;
                                
                                if ($diff < 60) {
                                    echo 'Baru saja';
                                } elseif ($diff < 3600) {
                                    echo floor($diff / 60) . ' menit yang lalu';
                                } elseif ($diff < 86400) {
                                    echo floor($diff / 3600) . ' jam yang lalu';
                                } else {
                                    echo format_tanggal(date('Y-m-d', $timestamp)) . ' ' . date('H:i', $timestamp);
                                }
                                ?>
                            </small>
                        </div>
                        
                        <div style="display: flex; gap: 5px;">
                            <?php if ($row['status_baca'] == 'belum'): ?>
                                <a href="?baca=<?php echo $row['id']; ?>" 
                                   class="btn btn-sm" 
                                   style="background: var(--secondary); color: white;"
                                   title="Tandai Sudah Dibaca">
                                    <i class="fas fa-check"></i>
                                </a>
                            <?php endif; ?>
                            <a href="?hapus=<?php echo $row['id']; ?>" 
                               onclick="return confirm('Hapus notifikasi ini?')" 
                               class="btn btn-danger btn-sm"
                               title="Hapus">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 60px 20px;">
                <i class="fas fa-bell-slash" style="font-size: 80px; color: #d1d5db; margin-bottom: 20px;"></i>
                <h3 style="color: #6b7280; margin-bottom: 10px;">Tidak Ada Notifikasi</h3>
                <p style="color: #9ca3af;">Anda belum memiliki notifikasi</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>