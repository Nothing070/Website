<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

// Proses register
if (isset($_POST['register'])) {
    $username = esc($_POST['username']);
    $password = md5($_POST['password']);
    $confirm_password = md5($_POST['confirm_password']);
    $nama_lengkap = esc($_POST['nama_lengkap']);
    $email = esc($_POST['email']);
    $role = 'anggota'; // Default role
    
    // Validasi
    if ($password != $confirm_password) {
        set_alert('danger', 'Password dan konfirmasi password tidak cocok!');
    } else {
        // Cek username sudah ada
        $check_query = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
        $check_result = mysqli_query($conn, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            set_alert('danger', 'Username atau email sudah terdaftar!');
        } else {
            // Insert user
            $query = "INSERT INTO users (username, password, nama_lengkap, email, role) 
                      VALUES ('$username', '$password', '$nama_lengkap', '$email', '$role')";
            
            if (mysqli_query($conn, $query)) {
                $user_id = mysqli_insert_id($conn);
                
                // Insert ke tabel anggota
                $anggota_query = "INSERT INTO anggota (user_id, status_anggota, tanggal_bergabung) 
                                  VALUES ('$user_id', 'aktif', CURDATE())";
                mysqli_query($conn, $anggota_query);
                
                set_alert('success', 'Registrasi berhasil! Silakan login.');
                header('Location: login.php');
                exit();
            } else {
                set_alert('danger', 'Registrasi gagal! ' . mysqli_error($conn));
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Karang Taruna</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-logo">
                <i class="fas fa-user-plus" style="font-size: 48px; color: var(--primary); margin-bottom: 10px;"></i>
                <h1>Daftar Anggota</h1>
                <p>Sistem Informasi Karang Taruna</p>
            </div>
            
            <?php show_alert(); ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="nama_lengkap">
                        <i class="fas fa-id-card"></i> Nama Lengkap
                    </label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" 
                           placeholder="Masukkan nama lengkap" required>
                </div>
                
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Username
                    </label>
                    <input type="text" class="form-control" id="username" name="username" 
                           placeholder="Masukkan username" required>
                </div>
                
                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i> Email
                    </label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Masukkan email" required>
                </div>
                
                <div class="form-group">
                <label for="password">
                    <i class="fas fa-lock"></i> Password
                </label>
                <div style="position: relative;">
                    <input type="password" class="form-control" id="password" name="password" 
                        placeholder="Masukkan password" required
                        style="padding-right: 45px;">
                    <span onclick="togglePassword('password', 'toggleIcon1')" 
                        style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #6b7280;">
                        <i class="fas fa-eye-slash" id="toggleIcon1"></i>
                    </span>
                </div>
            </div>

            <div class="form-group">
                <label for="confirm_password">
                    <i class="fas fa-lock"></i> Konfirmasi Password
                </label>
                <div style="position: relative;">
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                        placeholder="Konfirmasi password" required
                        style="padding-right: 45px;">
                    <span onclick="togglePassword('confirm_password', 'toggleIcon2')" 
                        style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #6b7280;">
                        <i class="fas fa-eye-slash" id="toggleIcon2"></i>
                    </span>
                </div>
            </div>
                
                <button type="submit" name="register" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Daftar
                </button>
            </form>
            
            <div class="auth-footer">
                Sudah punya akun? <a href="login.php">Login di sini</a>
            </div>
        </div>
    </div>
    <script>
        // Fungsi untuk toggle password visibility
        function togglePassword(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        }

        // Auto hide alert after 3 seconds
        setTimeout(function() {
            const alert = document.querySelector('.alert');
            if (alert) {
                alert.style.display = 'none';
            }
        }, 3000);
    </script>
</body>
</html>