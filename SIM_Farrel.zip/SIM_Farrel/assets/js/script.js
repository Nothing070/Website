// === HAMBURGER MENU TOGGLE ===
const toggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

toggle.addEventListener("click", () => {
    navLinks.classList.toggle("active"); // tampilkan/ sembunyikan menu
    toggle.classList.toggle("open");     // animasi X
});

// === PRELOADER FADE OUT ===
window.addEventListener("load", () => {
    const loader = document.querySelector(".preloader");
    loader.classList.add("fade-out");
    setTimeout(() => {
        loader.style.display = "none";
    }, 500);

    // === INISIALISASI AOS ===
    if (AOS) {
        AOS.init({
            duration: 800,   // durasi animasi
            once: true       // animasi hanya sekali saat scroll
        });
    }
});

// === OPTIONAL: CLOSE MENU ON LINK CLICK (MOBILE) ===
const navItems = document.querySelectorAll(".nav-links a");
navItems.forEach(item => {
    item.addEventListener("click", () => {
        if (navLinks.classList.contains("active")) {
            navLinks.classList.remove("active");
            toggle.classList.remove("open");
        }
    });
});
