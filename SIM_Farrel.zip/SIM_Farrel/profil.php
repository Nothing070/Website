<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

cek_login();

$page_title = 'Profil Saya';

// Ambil data user dan anggota
$user_id = $_SESSION['user_id'];
$query = "SELECT u.*, a.* 
          FROM users u 
          LEFT JOIN anggota a ON u.id = a.user_id 
          WHERE u.id = '$user_id'";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

// Proses update profil
if (isset($_POST['update_profil'])) {
    $nama_lengkap = esc($_POST['nama_lengkap']);
    $email = esc($_POST['email']);
    $tempat_lahir = esc($_POST['tempat_lahir']);
    $tanggal_lahir = esc($_POST['tanggal_lahir']);
    $jenis_kelamin = esc($_POST['jenis_kelamin']);
    $alamat = esc($_POST['alamat']);
    $no_telp = esc($_POST['no_telp']);
    $pekerjaan = esc($_POST['pekerjaan']);
    
    // Update users
    $update_user = "UPDATE users SET nama_lengkap = '$nama_lengkap', email = '$email' WHERE id = '$user_id'";
    mysqli_query($conn, $update_user);
    
    // Update anggota
    if ($data['id']) {
        $update_anggota = "UPDATE anggota SET 
                          tempat_lahir = '$tempat_lahir',
                          tanggal_lahir = '$tanggal_lahir',
                          jenis_kelamin = '$jenis_kelamin',
                          alamat = '$alamat',
                          no_telp = '$no_telp',
                          pekerjaan = '$pekerjaan'
                          WHERE user_id = '$user_id'";
        mysqli_query($conn, $update_anggota);
    }
    
    $_SESSION['nama_lengkap'] = $nama_lengkap;
    set_alert('success', 'Profil berhasil diupdate!');
    header('Location: profil.php');
    exit();
}

// Proses update foto profil
if (isset($_POST['update_foto'])) {
    if (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] == 0) {
        // Hapus foto lama jika bukan default
        if ($data['foto_profil'] != 'default.jpg') {
            hapus_file(FOTO_PROFIL_DIR . $data['foto_profil']);
        }
        
        // Upload foto baru
        $foto_baru = upload_file($_FILES['foto_profil'], FOTO_PROFIL_DIR, ['jpg', 'jpeg', 'png']);
        
        if ($foto_baru) {
            $update = "UPDATE users SET foto_profil = '$foto_baru' WHERE id = '$user_id'";
            if (mysqli_query($conn, $update)) {
                $_SESSION['foto_profil'] = $foto_baru;
                set_alert('success', 'Foto profil berhasil diupdate!');
            }
        } else {
            set_alert('danger', 'Gagal upload foto! Pastikan file adalah JPG/PNG dan ukuran maksimal 5MB');
        }
    }
    header('Location: profil.php');
    exit();
}

// Proses ganti password
if (isset($_POST['ganti_password'])) {
    $password_lama = md5($_POST['password_lama']);
    $password_baru = md5($_POST['password_baru']);
    $konfirmasi_password = md5($_POST['konfirmasi_password']);
    
    // Cek password lama
    $check = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id' AND password = '$password_lama'");
    
    if (mysqli_num_rows($check) == 0) {
        set_alert('danger', 'Password lama tidak sesuai!');
    } elseif ($password_baru != $konfirmasi_password) {
        set_alert('danger', 'Konfirmasi password tidak cocok!');
    } else {
        $update = "UPDATE users SET password = '$password_baru' WHERE id = '$user_id'";
        if (mysqli_query($conn, $update)) {
            set_alert('success', 'Password berhasil diubah!');
        }
    }
    header('Location: profil.php');
    exit();
}

include 'includes/header.php';
?>

<div style="display: grid; grid-template-columns: 350px 1fr; gap: 20px;">
    <!-- Sidebar Profil -->
    <div class="card" style="text-align: center;">
        <div style="position: relative; display: inline-block; margin-bottom: 20px;">
            <img src="<?php echo FOTO_PROFIL_DIR . $data['foto_profil']; ?>" 
                 style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 5px solid var(--primary);" 
                 alt="Foto Profil"
                 onerror="this.src='assets/img/default.jpg'">
            <button onclick="openModal('modalFoto')" 
                    style="position: absolute; bottom: 5px; right: 5px; width: 40px; height: 40px; border-radius: 50%; background: var(--primary); color: white; border: none; cursor: pointer; box-shadow: var(--shadow);">
                <i class="fas fa-camera"></i>
            </button>
        </div>
        
        <h3 style="margin-bottom: 5px;"><?php echo $data['nama_lengkap']; ?></h3>
        <p style="color: #6b7280; margin-bottom: 20px;">
            <span class="badge badge-info"><?php echo ucfirst($data['role']); ?></span>
        </p>
        
        <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; text-align: left;">
            <div style="margin-bottom: 15px;">
                <i class="fas fa-envelope" style="color: var(--primary); width: 25px;"></i>
                <span style="font-size: 14px;"><?php echo $data['email']; ?></span>
            </div>
            
            <?php if ($data['no_telp']): ?>
            <div style="margin-bottom: 15px;">
                <i class="fas fa-phone" style="color: var(--primary); width: 25px;"></i>
                <span style="font-size: 14px;"><?php echo $data['no_telp']; ?></span>
            </div>
            <?php endif; ?>
            
            <?php if ($data['pekerjaan']): ?>
            <div style="margin-bottom: 15px;">
                <i class="fas fa-briefcase" style="color: var(--primary); width: 25px;"></i>
                <span style="font-size: 14px;"><?php echo $data['pekerjaan']; ?></span>
            </div>
            <?php endif; ?>
            
            <?php if ($data['tanggal_bergabung']): ?>
            <div style="margin-bottom: 15px;">
                <i class="fas fa-calendar-check" style="color: var(--primary); width: 25px;"></i>
                <span style="font-size: 14px;">Bergabung: <?php echo format_tanggal($data['tanggal_bergabung']); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <button onclick="openModal('modalPassword')" class="btn btn-primary" style="margin-top: 20px; width: 100%;">
            <i class="fas fa-key"></i> Ganti Password
        </button>
    </div>
    
    <!-- Form Edit Profil -->
    <div class="card">
        <div class="card-header">
            <h4><i class="fas fa-user-edit"></i> Edit Profil</h4>
        </div>
        
        <form method="POST" action="">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Nama Lengkap *</label>
                    <input type="text" name="nama_lengkap" class="form-control" 
                           value="<?php echo $data['nama_lengkap']; ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" class="form-control" 
                           value="<?php echo $data['email']; ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control" 
                           value="<?php echo $data['tempat_lahir'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" 
                           value="<?php echo $data['tanggal_lahir'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-control">
                        <option value="L" <?php echo ($data['jenis_kelamin'] ?? '') == 'L' ? 'selected' : ''; ?>>Laki-laki</option>
                        <option value="P" <?php echo ($data['jenis_kelamin'] ?? '') == 'P' ? 'selected' : ''; ?>>Perempuan</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>No. Telepon</label>
                    <input type="text" name="no_telp" class="form-control" 
                           value="<?php echo $data['no_telp'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label>Pekerjaan</label>
                    <input type="text" name="pekerjaan" class="form-control" 
                           value="<?php echo $data['pekerjaan'] ?? ''; ?>">
                </div>
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Alamat</label>
                    <textarea name="alamat" class="form-control" rows="3"><?php echo $data['alamat'] ?? ''; ?></textarea>
                </div>
            </div>
            
            <button type="submit" name="update_profil" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Perubahan
            </button>
        </form>
    </div>
</div>

<!-- Modal Update Foto -->
<div id="modalFoto" class="modal">
    <div class="modal-content" style="max-width: 400px;">
        <span class="close-modal" onclick="closeModal('modalFoto')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-camera"></i> Update Foto Profil</h3>
        
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label>Pilih Foto Baru</label>
                <input type="file" name="foto_profil" class="form-control" 
                       accept="image/jpeg,image/jpg,image/png" required>
                <small style="color: #6b7280;">Format: JPG, PNG (Maks. 5MB)</small>
            </div>
            
            <button type="submit" name="update_foto" class="btn btn-primary">
                <i class="fas fa-upload"></i> Upload Foto
            </button>
        </form>
    </div>
</div>

<!-- Modal Ganti Password -->
<div id="modalPassword" class="modal">
    <div class="modal-content" style="max-width: 450px;">
        <span class="close-modal" onclick="closeModal('modalPassword')">&times;</span>
        <h3 style="margin-bottom: 20px;"><i class="fas fa-key"></i> Ganti Password</h3>
        
        <form method="POST" action="">
            <div class="form-group">
                <label>Password Lama *</label>
                <input type="password" name="password_lama" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Password Baru *</label>
                <input type="password" name="password_baru" class="form-control" 
                       minlength="6" required>
                <small style="color: #6b7280;">Minimal 6 karakter</small>
            </div>
            
            <div class="form-group">
                <label>Konfirmasi Password Baru *</label>
                <input type="password" name="konfirmasi_password" class="form-control" 
                       minlength="6" required>
            </div>
            
            <button type="submit" name="ganti_password" class="btn btn-primary">
                <i class="fas fa-check"></i> Ganti Password
            </button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>