<?php
// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'karang_taruna');

// Koneksi Database
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Set charset
mysqli_set_charset($conn, "utf8");

// Base URL
define('BASE_URL', 'http://localhost/karang_taruna/');

// Upload directories
define('UPLOAD_DIR', 'uploads/');
define('FOTO_PROFIL_DIR', UPLOAD_DIR . 'profil/');
define('FOTO_KEGIATAN_DIR', UPLOAD_DIR . 'kegiatan/');
define('BUKTI_TRANSAKSI_DIR', UPLOAD_DIR . 'bukti/');
?>