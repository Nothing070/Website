<?php include('../includes/header.php'); ?>

<section class="features" data-aos="fade-up">
    <h3>Tentang Karang Taruna</h3>
    <p style="max-width:700px; margin:0 auto; text-align:center;">
        Karang Taruna adalah organisasi sosial kepemudaan yang bergerak di bidang pemberdayaan masyarakat.
        Kami mengadakan berbagai kegiatan sosial, edukasi, dan kreatif untuk mendukung komunitas di sekitar kita.
    </p>
</section>

<section class="features" data-aos="fade-up" style="padding-bottom:80px;">
    <h3>Visi & Misi</h3>
    <div class="cards">
        <div class="card" data-aos="fade-up">
            <h4>Visi</h4>
            <p>Menjadi organisasi kepemudaan yang peduli dan aktif dalam memberdayakan masyarakat.</p>
        </div>
        <div class="card" data-aos="fade-up" data-aos-delay="100">
            <h4>Misi</h4>
            <p>Menyelenggarakan kegiatan sosial, edukasi, dan kreatif untuk komunitas yang lebih baik.</p>
        </div>
    </div>
</section>

<?php include('../includes/footer.php'); ?>
