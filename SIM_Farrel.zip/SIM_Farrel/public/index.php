<?php include('../includes/header.php'); ?>

<section class="hero">
    <div class="hero-text" data-aos="fade-up">
        <h2>Selamat Datang di <span>Karang Taruna</span></h2>
        <p>Mari berpartisipasi dalam kegiatan sosial dan pemberdayaan masyarakat.</p>
        <a href="about.php" class="btn-primary">Pelajari Lebih Lanjut</a>
    </div>
    <div class="hero-img" data-aos="fade-left">
        <img src="../assets/img/hero-bg.jpg" alt="Hero Image">
    </div>
</section>

<section class="features" data-aos="fade-up">
    <h3>Fitur Karang Taruna</h3>
    <div class="cards">
        <div class="card" data-aos="zoom-in">
            <i class='bx bxs-group'></i>
            <h4>Komunitas Aktif</h4>
            <p>Bergabung dengan komunitas sosial yang aktif dan peduli masyarakat.</p>
        </div>
        <div class="card" data-aos="zoom-in" data-aos-delay="100">
            <i class='bx bxs-bulb'></i>
            <h4>Program Kreatif</h4>
            <p>Mengadakan program kreatif untuk memberdayakan pemuda dan masyarakat.</p>
        </div>
        <div class="card" data-aos="zoom-in" data-aos-delay="200">
            <i class='bx bxs-rocket'></i>
            <h4>Pemberdayaan</h4>
            <p>Mendorong pemberdayaan masyarakat melalui kegiatan sosial dan edukasi.</p>
        </div>
    </div>
</section>

<section class="cta" data-aos="fade-up">
    <h3>Gabung dengan Karang Taruna Sekarang!</h3>
    <a href="login.php" class="btn-secondary">Login / Daftar</a>
</section>

<?php include('../includes/footer.php'); ?>
