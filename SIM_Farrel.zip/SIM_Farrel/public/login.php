<?php
include('../includes/header.php');
include('../includes/koneksi.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user'] = $user['username'];
            header("Location: index.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>

<section class="features" data-aos="fade-up" style="padding-top:80px; padding-bottom:80px;">
    <h3>Login / Daftar</h3>
    <?php if(isset($error)) echo "<p style='color:red; text-align:center;'>$error</p>"; ?>
    
    <form action="" method="POST" style="max-width:400px; margin:30px auto; display:flex; flex-direction:column; gap:15px;">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="btn-primary">Login</button>
        <p style="text-align:center;">Belum punya akun? <a href="#">Daftar</a></p>
    </form>
</section>

<?php include('../includes/footer.php'); ?>
