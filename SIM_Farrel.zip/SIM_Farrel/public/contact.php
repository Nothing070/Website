<?php
include('../includes/header.php');
include('../includes/koneksi.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pesan = mysqli_real_escape_string($conn, $_POST['pesan']);

    $query = "INSERT INTO messages (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')";
    if (mysqli_query($conn, $query)) {
        $success = "Pesan berhasil dikirim!";
    } else {
        $error = "Terjadi kesalahan: " . mysqli_error($conn);
    }
}
?>

<section class="features" data-aos="fade-up">
    <h3>Kontak Kami</h3>
    <?php if(isset($success)) echo "<p style='color:green; text-align:center;'>$success</p>"; ?>
    <?php if(isset($error)) echo "<p style='color:red; text-align:center;'>$error</p>"; ?>
    
    <form action="" method="POST" style="max-width:500px; margin:30px auto; display:flex; flex-direction:column; gap:15px;">
        <input type="text" name="nama" placeholder="Nama" required>
        <input type="email" name="email" placeholder="Email" required>
        <textarea name="pesan" rows="5" placeholder="Pesan" required></textarea>
        <button type="submit" class="btn-primary">Kirim Pesan</button>
    </form>
</section>

<?php include('../includes/footer.php'); ?>
