<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Karang Taruna</title>
  <link rel="stylesheet" href="/assets/css/style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body>
  <!-- Preloader -->
  <div class="preloader">
      <div class="loader"></div>
  </div>

  <!-- Navbar -->
  <nav class="navbar">
      <div class="container">
          <div class="logo">
              <img src="/assets/img/logo.png" alt="Logo Karang Taruna">
              <h1>Karang Taruna</h1>
          </div>

          <ul class="nav-links">
              <li><a href="/public/index.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='index.php' ? 'active' : '' ?>">Beranda</a></li>
              <li><a href="/public/about.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='about.php' ? 'active' : '' ?>">Tentang</a></li>
              <li><a href="/public/contact.php" class="<?php echo basename($_SERVER['PHP_SELF'])=='contact.php' ? 'active' : '' ?>">Kontak</a></li>
              <li><a href="/public/login.php" class="btn-login <?php echo basename($_SERVER['PHP_SELF'])=='login.php' ? 'active' : '' ?>">Login</a></li>
          </ul>

          <!-- Hamburger Menu -->
          <div class="menu-toggle" id="hamburger">
              <span></span>
              <span></span>
              <span></span>
          </div>
      </div>
  </nav>
