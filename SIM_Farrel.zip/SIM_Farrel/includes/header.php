<?php
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Ambil data user
$user_data = get_user_data($_SESSION['user_id'], $conn);

// Hitung notifikasi belum dibaca
$notif_query = "SELECT COUNT(*) as total FROM notifikasi 
                WHERE user_id = '{$_SESSION['user_id']}' AND status_baca = 'belum'";
$notif_result = mysqli_query($conn, $notif_query);
$notif_data = mysqli_fetch_assoc($notif_result);
$unread_notif = $notif_data['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title : 'Dashboard'; ?> - Karang Taruna</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2><i class="fas fa-users"></i> Karang Taruna</h2>
                <p>Sistem Informasi Manajemen</p>
            </div>
            
            <nav class="sidebar-menu">
                <!-- Menu untuk SEMUA ROLE -->
                <a href="dashboard.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                
                <!-- Menu untuk ADMIN -->
                <?php if ($_SESSION['role'] == 'admin'): ?>
                    <a href="keuangan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'keuangan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-money-bill-wave"></i> Keuangan
                    </a>
                    <a href="kegiatan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'kegiatan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Kegiatan
                    </a>
                    <a href="anggota.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'anggota.php' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i> Data Anggota
                    </a>
                    <a href="iuran.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'iuran.php' ? 'active' : ''; ?>">
                        <i class="fas fa-hand-holding-usd"></i> Iuran
                    </a>
                    <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-file-alt"></i> Laporan
                    </a>
                
                <!-- Menu untuk KETUA -->
                <?php elseif ($_SESSION['role'] == 'ketua'): ?>
                    <a href="kegiatan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'kegiatan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Kegiatan
                    </a>
                    <a href="anggota.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'anggota.php' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i> Data Anggota
                    </a>
                    <a href="keuangan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'keuangan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-money-bill-wave"></i> Keuangan (View)
                    </a>
                    <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-file-alt"></i> Laporan
                    </a>
                
                <!-- Menu untuk SEKRETARIS -->
                <?php elseif ($_SESSION['role'] == 'sekretaris'): ?>
                    <a href="anggota.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'anggota.php' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i> Data Anggota
                    </a>
                    <a href="kegiatan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'kegiatan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Kegiatan (View)
                    </a>
                    <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-file-alt"></i> Laporan
                    </a>
                
                <!-- Menu untuk BENDAHARA -->
                <?php elseif ($_SESSION['role'] == 'bendahara'): ?>
                    <a href="keuangan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'keuangan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-money-bill-wave"></i> Keuangan
                    </a>
                    <a href="iuran.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'iuran.php' ? 'active' : ''; ?>">
                        <i class="fas fa-hand-holding-usd"></i> Iuran
                    </a>
                    <a href="kegiatan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'kegiatan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Kegiatan (View)
                    </a>
                    <a href="laporan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-file-alt"></i> Laporan
                    </a>
                
                <!-- Menu untuk ANGGOTA BIASA -->
                <?php else: ?>
                    <a href="kegiatan.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'kegiatan.php' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-alt"></i> Kegiatan
                    </a>
                    <a href="iuran.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'iuran.php' ? 'active' : ''; ?>">
                        <i class="fas fa-hand-holding-usd"></i> Iuran Saya
                    </a>
                <?php endif; ?>
                
                <!-- Menu untuk SEMUA ROLE -->
                <a href="notifikasi.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'notifikasi.php' ? 'active' : ''; ?>">
                    <i class="fas fa-bell"></i> Notifikasi
                    <?php if ($unread_notif > 0): ?>
                        <span class="badge badge-danger" style="float: right;"><?php echo $unread_notif; ?></span>
                    <?php endif; ?>
                </a>
                
                <a href="profil.php" class="menu-item <?php echo basename($_SERVER['PHP_SELF']) == 'profil.php' ? 'active' : ''; ?>">
                    <i class="fas fa-user-circle"></i> Profil Saya
                </a>
                
                <a href="logout.php" class="menu-item" onclick="return confirm('Yakin ingin logout?')">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <!-- Topbar -->
            <div class="topbar">
                <div class="topbar-left">
                    <h3><?php echo isset($page_title) ? $page_title : 'Dashboard'; ?></h3>
                </div>
                
                <div class="topbar-right">
                <div class="user-profile">
                    <img src="assets/img/icon.png" 
                        alt="Logo Karang Taruna" 
                        class="user-avatar" 
                        style="border-radius: 50%; width: 45px; height: 45px; object-fit: cover;">
                    <div>
                        <strong><?php echo $_SESSION['nama_lengkap']; ?></strong>
                        <br>
                        <small style="color: #6b7280;"><?php echo ucfirst($_SESSION['role']); ?></small>
                    </div>
                </div>
            </div>
            </div>
            
            <!-- Content Area -->
            <div class="content-area">
                <?php show_alert(); ?>