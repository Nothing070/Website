<?php
// Fungsi untuk cek session login
function cek_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
}

// Fungsi untuk cek role
function cek_role($allowed_roles) {
    if (!in_array($_SESSION['role'], $allowed_roles)) {
        header('Location: dashboard.php');
        exit();
    }
}

// Fungsi format rupiah
function format_rupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Fungsi format tanggal Indonesia
function format_tanggal($tanggal) {
    $bulan = array(
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    );
    $pecah = explode('-', $tanggal);
    return $pecah[2] . ' ' . $bulan[(int)$pecah[1]] . ' ' . $pecah[0];
}

// Fungsi upload file
function upload_file($file, $directory, $allowed_types = ['jpg', 'jpeg', 'png', 'pdf']) {
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    
    if ($file_error === 0) {
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        if (in_array($file_ext, $allowed_types)) {
            if ($file_size <= 5000000) { // 5MB
                $new_file_name = uniqid('', true) . '.' . $file_ext;
                $file_destination = $directory . $new_file_name;
                
                if (move_uploaded_file($file_tmp, $file_destination)) {
                    return $new_file_name;
                }
            }
        }
    }
    return false;
}

// Fungsi hapus file
function hapus_file($file_path) {
    if (file_exists($file_path) && $file_path != 'default.jpg') {
        unlink($file_path);
    }
}

// Fungsi ambil data user
function get_user_data($user_id, $conn) {
    $query = "SELECT * FROM users WHERE id = '$user_id'";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($result);
}

// Fungsi hitung total kas
function hitung_total_kas($conn) {
    $query = "SELECT 
                (SELECT COALESCE(SUM(jumlah), 0) FROM keuangan WHERE jenis_transaksi = 'masuk') -
                (SELECT COALESCE(SUM(jumlah), 0) FROM keuangan WHERE jenis_transaksi = 'keluar') 
                AS total_kas";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['total_kas'];
}

// Fungsi hitung total anggota aktif
function hitung_anggota_aktif($conn) {
    $query = "SELECT COUNT(*) as total FROM anggota WHERE status_anggota = 'aktif'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['total'];
}

// Fungsi hitung kegiatan bulan ini
function hitung_kegiatan_bulan_ini($conn) {
    $bulan_ini = date('Y-m');
    $query = "SELECT COUNT(*) as total FROM kegiatan 
              WHERE DATE_FORMAT(tanggal_mulai, '%Y-%m') = '$bulan_ini'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    return $data['total'];
}

// Fungsi escape string
function esc($str) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars($str));
}

// Fungsi alert
function set_alert($type, $message) {
    $_SESSION['alert'] = [
        'type' => $type,
        'message' => $message
    ];
}

function show_alert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        echo '<div class="alert alert-' . $alert['type'] . ' alert-dismissible">';
        echo $alert['message'];
        echo '<button type="button" class="btn-close" onclick="this.parentElement.style.display=\'none\'"></button>';
        echo '</div>';
        unset($_SESSION['alert']);
    }
}

// Fungsi pagination
function pagination($total_data, $per_page, $page, $url) {
    $total_pages = ceil($total_data / $per_page);
    
    if ($total_pages <= 1) return '';
    
    $html = '<div class="pagination">';
    
    // Previous
    if ($page > 1) {
        $html .= '<a href="' . $url . '?page=' . ($page - 1) . '">&laquo; Prev</a>';
    }
    
    // Numbers
    for ($i = 1; $i <= $total_pages; $i++) {
        if ($i == $page) {
            $html .= '<a href="#" class="active">' . $i . '</a>';
        } else {
            $html .= '<a href="' . $url . '?page=' . $i . '">' . $i . '</a>';
        }
    }
    
    // Next
    if ($page < $total_pages) {
        $html .= '<a href="' . $url . '?page=' . ($page + 1) . '">Next &raquo;</a>';
    }
    
    $html .= '</div>';
    return $html;
}
?>