<footer class="footer">
  <div class="container">
      <p>© 2025 Karang Taruna. Semua Hak Dilindungi.</p>
      <div class="socials">
          <a href="#"><i class='bx bxl-facebook'></i></a>
          <a href="#"><i class='bx bxl-instagram'></i></a>
          <a href="#"><i class='bx bxl-twitter'></i></a>
      </div>
  </div>
</footer>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="/assets/js/script.js"></script>
<script>
    // Inisialisasi AOS
    AOS.init();

    // Hamburger menu toggle
    const toggle = document.getElementById("hamburger");
    const navLinks = document.querySelector(".nav-links");

    toggle.addEventListener("click", () => {
        navLinks.classList.toggle("active");
        toggle.classList.toggle("open");
    });

    // Preloader fade out
    window.addEventListener("load", () => {
      const loader = document.querySelector(".preloader");
      loader.classList.add("fade-out");
      setTimeout(() => loader.style.display = "none", 500);
    });
</script>
</body>
</html>
